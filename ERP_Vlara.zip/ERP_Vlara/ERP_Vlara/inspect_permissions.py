import frappe

def run():
    print("--- User Permissions ---")
    user_perms = frappe.db.sql("SELECT name, user, allow, for_value FROM `tabUser Permission`", as_dict=True)
    for up in user_perms:
        print(up)
    
    print("\n--- Default Values ---")
    def_vals = frappe.db.sql("SELECT name, parent, defkey, defvalue FROM `tabDefaultValue` WHERE defkey='company' OR defkey='Company'", as_dict=True)
    for dv in def_vals:
        print(dv)

    print("\n--- System Settings / Global Defaults ---")
    gd = frappe.db.sql("SELECT default_company FROM `tabGlobal Defaults`", as_dict=True)
    print("Global defaults:", gd)
    
    print("\n--- Users ---")
    users = frappe.db.sql("SELECT name, email, full_name FROM `tabUser`", as_dict=True)
    for u in users:
        print(u)
