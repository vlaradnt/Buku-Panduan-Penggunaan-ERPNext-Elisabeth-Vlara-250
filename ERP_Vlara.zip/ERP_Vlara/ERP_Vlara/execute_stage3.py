import frappe
from frappe.utils import nowdate
from erpnext.manufacturing.doctype.work_order.work_order import make_stock_entry

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    raw_warehouse = "Stores - VD"
    wip_warehouse = "Work In Progress - VD"
    fg_warehouse = "Finished Goods - VD"
    fg_item = "FG-MEJA-01"
    today = nowdate()

    print("==================================================================")
    print("=== MEMULAI EKSEKUSI TAHAP 3: MANUFAKTUR & PRODUKSI ===")
    print("==================================================================")

    # 1. Buat Bill of Materials (BOM)
    print("\n--- 1. Pembuatan Resep Produksi (Bill of Materials / BOM) ---")
    
    existing_bom = frappe.get_all("BOM", filters={"item": fg_item, "docstatus": 1, "is_default": 1}, fields=["name", "raw_material_cost"])
    
    if existing_bom:
        bom_name = existing_bom[0].name
        rm_cost = existing_bom[0].raw_material_cost
        print(f"[OK] BOM Default untuk {fg_item} sudah ada: {bom_name}")
        print(f"     Total Biaya Bahan Baku per Meja: Rp {rm_cost:,.2f}")
    else:
        bom_doc = frappe.new_doc("BOM")
        bom_doc.item = fg_item
        bom_doc.quantity = 1
        bom_doc.company = company
        bom_doc.is_active = 1
        bom_doc.is_default = 1
        bom_doc.currency = "IDR"
        bom_doc.rm_cost_as_per = "Valuation Rate"

        # Bahan Baku sesuai Resep 1 Meja
        materials = [
            {"item_code": "RM-KAYU-01", "qty": 1, "uom": "Nos", "rate": 85000.0},
            {"item_code": "RM-BESI-01", "qty": 4, "uom": "Nos", "rate": 40000.0},
            {"item_code": "RM-BAUT-01", "qty": 16, "uom": "Nos", "rate": 1500.0},
            {"item_code": "RM-CAT-01", "qty": 0.5, "uom": "Litre", "rate": 60000.0}
        ]

        for m in materials:
            bom_doc.append("items", m)

        bom_doc.save(ignore_permissions=True)
        bom_doc.submit()
        bom_name = bom_doc.name
        print(f"[OK] BOM Berhasil Dibuat & Disubmit: {bom_name}")
        print(f"     Total Biaya Bahan Baku per Meja: Rp {bom_doc.raw_material_cost:,.2f}")

    # 2. Buat Work Order (Perintah Kerja Produksi 5 Unit Meja)
    print("\n--- 2. Pembuatan Work Order (Produksi 5 Unit Meja) ---")
    qty_to_produce = 5

    # Cek WO yang belum selesai
    existing_wo = frappe.get_all("Work Order", filters={"production_item": fg_item, "docstatus": 1, "status": ["!=", "Completed"]}, fields=["name", "status"])
    if existing_wo:
        wo_doc = frappe.get_doc("Work Order", existing_wo[0].name)
        print(f"Menggunakan Work Order yang sedang berjalan: {wo_doc.name} (Status: {wo_doc.status})")
    else:
        wo_doc = frappe.new_doc("Work Order")
        wo_doc.company = company
        wo_doc.production_item = fg_item
        wo_doc.bom_no = bom_name
        wo_doc.qty = qty_to_produce
        wo_doc.planned_start_date = today
        wo_doc.source_warehouse = raw_warehouse
        wo_doc.wip_warehouse = wip_warehouse
        wo_doc.fg_warehouse = fg_warehouse

        wo_doc.save(ignore_permissions=True)
        wo_doc.submit()
        print(f"[OK] Work Order Dibuat & Disubmit: {wo_doc.name} (Jumlah: {qty_to_produce} unit {fg_item})")
        print(f"     Status WO: {wo_doc.status}")

    # 3. Langkah Start: Material Transfer for Manufacture (Stores -> WIP)
    print("\n--- 3. Transfer Bahan Baku ke Ruang Produksi (Stores -> WIP) ---")
    # make_stock_entry returns a dict
    ste_transfer_dict = make_stock_entry(wo_doc.name, "Material Transfer for Manufacture", qty_to_produce)
    ste_transfer = frappe.get_doc(ste_transfer_dict)
    ste_transfer.posting_date = today
    ste_transfer.insert(ignore_permissions=True)
    ste_transfer.submit()
    print(f"[OK] Stock Entry (Material Transfer) Disubmit: {ste_transfer.name}")
    print("     Bahan Baku berhasil dipindahkan ke Gudang Produksi (WIP):")
    for itm in ste_transfer.items:
        print(f"      - {itm.item_code} ({itm.item_name}): {itm.qty} {itm.uom} [Dari: {itm.s_warehouse} -> Ke: {itm.t_warehouse}]")

    wo_doc.reload()
    print(f"     Status WO Sekarang: {wo_doc.status}")

    # 4. Langkah Finish: Manufacture (WIP -> Finished Goods)
    print("\n--- 4. Penyelesaian Produksi / Finish (WIP -> Finished Goods) ---")
    ste_finish_dict = make_stock_entry(wo_doc.name, "Manufacture", qty_to_produce)
    ste_finish = frappe.get_doc(ste_finish_dict)
    ste_finish.posting_date = today
    ste_finish.insert(ignore_permissions=True)
    ste_finish.submit()
    print(f"[OK] Stock Entry (Manufacture) Disubmit: {ste_finish.name}")
    print(f"     5 Unit Meja Jadi ({fg_item}) resmi masuk ke {fg_warehouse}!")

    wo_doc.reload()
    print(f"     Status Akhir WO: {wo_doc.status} (Produced Qty: {wo_doc.produced_qty})")

    frappe.db.commit()

    print("\n" + "="*65)
    print("=== STATUS SALDO SEMUA GUDANG SETELAH SELESAI PRODUKSI ===")
    print("="*65)
    
    stock_balances = frappe.db.sql("""
        SELECT warehouse, item_code, SUM(actual_qty) as qty 
        FROM `tabStock Ledger Entry` 
        WHERE company = %s 
        GROUP BY warehouse, item_code
        HAVING SUM(actual_qty) > 0
        ORDER BY warehouse, item_code
    """, company, as_dict=True)

    current_wh = ""
    for sb in stock_balances:
        if sb.warehouse != current_wh:
            current_wh = sb.warehouse
            print(f"\n📍 Gudang: {current_wh}")
        print(f"   • {sb.item_code:<15} : {sb.qty:>6.1f} unit")

if __name__ == "__main__":
    run()
