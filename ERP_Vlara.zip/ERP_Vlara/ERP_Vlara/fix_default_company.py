import frappe

def run():
    print("--- Checking tabDefaultValue ---")
    rows = frappe.db.sql("SELECT * FROM `tabDefaultValue` WHERE defvalue LIKE '%Vlara%' OR defkey='company' OR defkey='Company'", as_dict=True)
    for r in rows:
        print(r)

    print("\n--- Updating default company to 'Vlara Danita' ---")
    frappe.db.sql("UPDATE `tabDefaultValue` SET defvalue='Vlara Danita' WHERE defkey IN ('company', 'Company')")
    
    # Also set for specific users
    users = ["Administrator", "vdanita2005@gmail.com"]
    for u in users:
        frappe.db.set_default("company", "Vlara Danita", parent=u)
        frappe.db.set_default("Company", "Vlara Danita", parent=u)
    
    frappe.db.set_default("company", "Vlara Danita", parent="__default")
    frappe.db.set_default("Company", "Vlara Danita", parent="__default")
    
    frappe.db.commit()
    frappe.clear_cache()
    print("Successfully updated defaults and cleared cache!")
    
    rows_after = frappe.db.sql("SELECT * FROM `tabDefaultValue` WHERE defkey IN ('company', 'Company')", as_dict=True)
    for r in rows_after:
        print("Updated:", r)
