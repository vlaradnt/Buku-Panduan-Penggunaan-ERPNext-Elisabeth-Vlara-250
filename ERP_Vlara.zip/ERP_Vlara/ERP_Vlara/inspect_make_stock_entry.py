import inspect
from erpnext.manufacturing.doctype.work_order.work_order import make_stock_entry

def run():
    print(inspect.getsource(make_stock_entry))
