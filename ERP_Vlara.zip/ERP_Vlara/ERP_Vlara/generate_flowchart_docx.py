import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls
from PIL import Image, ImageDraw, ImageFont

def create_flowchart_image(output_image_path):
    # Canvas dimensions
    width = 1600
    height = 2300
    img = Image.new("RGB", (width, height), "#F8FAFC")
    draw = ImageDraw.Draw(img)

    # Fonts
    font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36)
    font_subtitle = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
    font_stage = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
    font_box_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
    font_box_text = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
    font_badge = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14)

    # Header Banner
    draw.rectangle([(0, 0), (width, 140)], fill="#0F172A")
    draw.text((width // 2, 45), "ALUR SISTEM PERSEDIAAN (INVENTORY) ERPNEXT", fill="#FFFFFF", font=font_title, anchor="mm")
    draw.text((width // 2, 95), "Siklus Manufaktur: Pengadaan Bahan Baku -> WIP -> Produk Jadi -> Penjualan", fill="#94A3B8", font=font_subtitle, anchor="mm")

    # Helper function to draw rounded box
    def draw_card(x, y, w, h, bg_color, border_color, title, texts, badge=None, badge_color="#3B82F6"):
        # Shadow
        draw.rounded_rectangle([(x + 4, y + 4), (x + w + 4, y + h + 4)], radius=16, fill="#E2E8F0")
        # Main Box
        draw.rounded_rectangle([(x, y), (x + w, y + h)], radius=16, fill=bg_color, outline=border_color, width=2)
        
        # Header text
        curr_y = y + 25
        if badge:
            # Draw badge
            bw = 140
            bh = 26
            bx = x + w - bw - 20
            by = y + 16
            draw.rounded_rectangle([(bx, by), (bx + bw, by + bh)], radius=8, fill=badge_color)
            draw.text((bx + bw // 2, by + bh // 2), badge, fill="#FFFFFF", font=font_badge, anchor="mm")

        draw.text((x + 24, curr_y), title, fill="#0F172A", font=font_box_title)
        curr_y += 35
        for t in texts:
            draw.text((x + 24, curr_y), t, fill="#334155", font=font_box_text)
            curr_y += 24

    # Helper function to draw arrow
    def draw_down_arrow(cx, start_y, end_y, label=""):
        draw.line([(cx, start_y), (cx, end_y)], fill="#64748B", width=4)
        # Arrowhead
        ah = 12
        draw.polygon([(cx - ah, end_y - ah), (cx + ah, end_y - ah), (cx, end_y)], fill="#64748B")
        if label:
            draw.rounded_rectangle([(cx + 10, (start_y + end_y) // 2 - 14), (cx + 260, (start_y + end_y) // 2 + 14)], radius=6, fill="#FFFFFF", outline="#CBD5E1", width=1)
            draw.text((cx + 135, (start_y + end_y) // 2), label, fill="#475569", font=font_box_text, anchor="mm")

    box_w = 950
    box_x = (width - box_w) // 2
    
    # ------------------ STAGE 1: PENGADAAN BAHAN BAKU ------------------
    s1_y = 175
    draw.rounded_rectangle([(box_x - 30, s1_y), (box_x + box_w + 30, s1_y + 40)], radius=8, fill="#E0F2FE")
    draw.text((width // 2, s1_y + 20), "TAHAP 1: PENGADAAN & PENERIMAAN BAHAN BAKU (INBOUND)", fill="#0369A1", font=font_stage, anchor="mm")
    
    # Box 1.1: Purchase Order
    b1_y = s1_y + 60
    b1_h = 125
    draw_card(box_x, b1_y, box_w, b1_h, "#FFFFFF", "#38BDF8", 
              "1. Purchase Order (PO) ke Supplier", 
              ["• Supplier: PT Rimba Kayu Lestari, CV Logam Baja Perkasa, Toko Cat Sumber Warna",
               "• Pesan item: Kayu Mahoni, Kaki Besi, Baut & Sekrup, Cat Finishing",
               "• Efek Persediaan: Belum mengubah stok fisik (hanya komitmen pemesanan)"],
              badge="Buying Module", badge_color="#0284C7")

    draw_down_arrow(width // 2, b1_y + b1_h, b1_y + b1_h + 55, "Barang Dikirim Supplier")

    # Box 1.2: Purchase Receipt (Masuk Gudang)
    b2_y = b1_y + b1_h + 55
    b2_h = 145
    draw_card(box_x, b2_y, box_w, b2_h, "#FEF3C7", "#F59E0B", 
              "2. Purchase Receipt (Tanda Terima Barang Gudang)", 
              ["• Target Gudang: Stores - VD (Gudang Bahan Baku)",
               "• Stok Bertambah: +15 Papan Kayu, +50 Kaki Besi, +200 Baut, +10 Liter Cat",
               "• Akuntansi Otomatis: Debit Persediaan Bahan Baku | Kredit Hutang Belum Ditagih",
               "• Dokumen Lanjutan: Purchase Invoice (Faktur Pembelian) & Pembayaran Kas/Bank"],
              badge="Stok Masuk (+)", badge_color="#D97706")

    draw_down_arrow(width // 2, b2_y + b2_h, b2_y + b2_h + 65, "Pemicu Rencana Produksi")

    # ------------------ STAGE 2: PRODUKSI & PERSEDIAAN WIP ------------------
    s2_y = b2_y + b2_h + 65
    draw.rounded_rectangle([(box_x - 30, s2_y), (box_x + box_w + 30, s2_y + 40)], radius=8, fill="#EDE9FE")
    draw.text((width // 2, s2_y + 20), "TAHAP 2: PROSES MANUFAKTUR & MUTASI WIP (WORK IN PROGRESS)", fill="#6D28D9", font=font_stage, anchor="mm")

    # Box 2.1: Work Order & BOM
    b3_y = s2_y + 60
    b3_h = 125
    draw_card(box_x, b3_y, box_w, b3_h, "#FFFFFF", "#818CF8", 
              "3. Perintah Kerja Produksi (Work Order & BOM)", 
              ["• Referensi BOM: FG-MEJA-01 (Resep 1 unit meja = 1 kayu, 4 kaki besi, 16 baut, 0.5L cat)",
               "• Target Produksi: 5 Unit Meja Kerja Kayu Minimalis",
               "• Efek Persediaan: Mereservasi kebutuhan bahan baku di gudang Stores - VD"],
              badge="Manufacturing", badge_color="#4F46E5")

    draw_down_arrow(width // 2, b3_y + b3_h, b3_y + b3_h + 55, "Klik Tombol 'Start'")

    # Box 2.2: Stock Entry - Material Transfer
    b4_y = b3_y + b3_h + 55
    b4_h = 145
    draw_card(box_x, b4_y, box_w, b4_h, "#F5F3FF", "#A78BFA", 
              "4. Stock Entry: Material Transfer for Manufacture", 
              ["• Gudang Asal: Stores - VD (Bahan Baku Berkurang -RM)",
               "• Gudang Tujuan: Work In Progress - VD (Persediaan WIP Bertambah +WIP)",
               "• Barang Dimutasi: 5 Kayu, 20 Kaki Besi, 80 Baut, 2.5 Liter Cat",
               "• Akuntansi Otomatis: Debit Persediaan WIP | Kredit Persediaan Bahan Baku"],
              badge="Mutasi Antar Gudang", badge_color="#7C3AED")

    draw_down_arrow(width // 2, b4_y + b4_h, b4_y + b4_h + 55, "Klik Tombol 'Finish'")

    # Box 2.3: Stock Entry - Manufacture (Barang Jadi Masuk)
    b5_y = b4_y + b4_h + 55
    b5_h = 145
    draw_card(box_x, b5_y, box_w, b5_h, "#ECFDF5", "#34D399", 
              "5. Stock Entry: Manufacture (Penyelesaian Barang Jadi)", 
              ["• Gudang Asal: Work In Progress - VD (Bahan dalam perakitan dihapus/dikonsumsi)",
               "• Gudang Tujuan: Finished Goods - VD (Barang Jadi Bertambah +5 FG-MEJA-01)",
               "• Nilai Masuk Produk: Total HPP Rp 299.000 x 5 = Rp 1.495.000",
               "• Akuntansi Otomatis: Debit Persediaan Barang Jadi | Kredit Persediaan WIP"],
              badge="Barang Jadi (+)", badge_color="#059669")

    draw_down_arrow(width // 2, b5_y + b5_h, b5_y + b5_h + 65, "Permintaan Pembeli")

    # ------------------ STAGE 3: PENGELUARAN PENJUALAN ------------------
    s3_y = b5_y + b5_h + 65
    draw.rounded_rectangle([(box_x - 30, s3_y), (box_x + box_w + 30, s3_y + 40)], radius=8, fill="#FFE4E6")
    draw.text((width // 2, s3_y + 20), "TAHAP 3: PENJUALAN & PENGELUARAN PERSEDIAAN (OUTBOUND)", fill="#BE123C", font=font_stage, anchor="mm")

    # Box 3.1: Sales Order & Delivery Note
    b6_y = s3_y + 60
    b6_h = 155
    draw_card(box_x, b6_y, box_w, b6_h, "#FFF1F2", "#FB7185", 
              "6. Delivery Note (Surat Jalan & Pengiriman Produk Jadi)", 
              ["• Pelanggan: CV Sentra Mebel Indonesia (Pesanan 3 Unit Meja)",
               "• Gudang Pengeluaran: Finished Goods - VD (Stok Meja Jadi Berkurang -3 Unit)",
               "• Akuntansi Otomatis: Debit Beban Pokok Penjualan (HPP) | Kredit Persediaan Barang Jadi",
               "• Dokumen Lanjutan: Sales Invoice (Faktur Penjualan Rp 1.950.000) & Penerimaan Kas"],
              badge="Stok Keluar (-)", badge_color="#E11D48")

    draw_down_arrow(width // 2, b6_y + b6_h, b6_y + b6_h + 55, "Audit & Evaluasi")

    # Box 4: Laporan & Monitoring
    b7_y = b6_y + b6_h + 55
    b7_h = 135
    draw_card(box_x, b7_y, box_w, b7_h, "#F8FAFC", "#64748B", 
              "7. Monitoring & Laporan Persediaan Real-Time", 
              ["• Stock Ledger: Melacak riwayat keluar-masuk setiap lot barang dengan metode FIFO",
               "• Stock Balance: Menampilkan saldo kuantitas dan nilai rupiah persediaan di tiap gudang",
               "• Laporan Laba Rugi: Mencatat margin laba kotor penjualan produk jadi"],
              badge="Pelaporan Stok", badge_color="#475569")

    img.save(output_image_path, "PNG", quality=95)
    print(f"Flowchart image created: {output_image_path}")

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def create_flowchart_docx(docx_path, image_path):
    doc = docx.Document()

    # Page Margins
    for s in doc.sections:
        s.top_margin = Inches(0.8)
        s.bottom_margin = Inches(0.8)
        s.left_margin = Inches(0.8)
        s.right_margin = Inches(0.8)

    # ----------------- HEADER & TITLE -----------------
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(4)
    p_title.paragraph_format.space_after = Pt(2)
    r_title = p_title.add_run("FLOWCHART & PANDUAN SISTEM PERSEDIAAN (INVENTORY) ERPNEXT")
    r_title.bold = True
    r_title.font.name = "Calibri"
    r_title.font.size = Pt(18)
    r_title.font.color.rgb = RGBColor(15, 23, 42)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(14)
    r_sub = p_sub.add_run("Studi Kasus Industri Manufaktur Furniture — Perusahaan: Vlara Danita\nAlur Mutasi Stok: Pembelian Bahan Baku -> Transfer WIP -> Barang Jadi -> Pengiriman Penjualan")
    r_sub.italic = True
    r_sub.font.name = "Calibri"
    r_sub.font.size = Pt(11)
    r_sub.font.color.rgb = RGBColor(71, 85, 105)

    # Divider line
    p_div = doc.add_paragraph()
    p_div.paragraph_format.space_after = Pt(12)
    p_border = parse_xml(f'<w:pBdr {nsdecls("w")}><w:bottom w:val="single" w:sz="12" w:space="1" w:color="0284C7"/></w:pBdr>')
    p_div._p.get_or_add_pPr().append(p_border)

    # ----------------- BAB 1: DIAGRAM FLOWCHART -----------------
    h1 = doc.add_heading(level=1)
    h1.paragraph_format.space_before = Pt(12)
    h1.paragraph_format.space_after = Pt(6)
    r_h1 = h1.add_run("1. Diagram Alur Sistem Persediaan (Visual Flowchart)")
    r_h1.font.name = "Calibri"
    r_h1.font.size = Pt(14)
    r_h1.font.color.rgb = RGBColor(2, 132, 199)

    p_desc = doc.add_paragraph()
    p_desc.paragraph_format.space_after = Pt(10)
    r_desc = p_desc.add_run("Berikut adalah diagram alir (*flowchart*) menyeluruh siklus persediaan barang di ERPNext, mulai dari pengadaan bahan mentah, mutasi barang setengah jadi di ruang produksi, hingga penyerahan barang jadi ke pelanggan:")
    r_desc.font.name = "Calibri"
    r_desc.font.size = Pt(10.5)

    # Insert Image
    if os.path.exists(image_path):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(4)
        p_img.paragraph_format.space_after = Pt(12)
        doc.add_picture(image_path, width=Inches(6.8))
        
        p_cap = doc.add_paragraph()
        p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_cap.paragraph_format.space_after = Pt(16)
        r_cap = p_cap.add_run("Gambar 1: Flowchart Siklus Persediaan Manufaktur ERPNext (Perpetual Inventory)")
        r_cap.italic = True
        r_cap.font.name = "Calibri"
        r_cap.font.size = Pt(9.5)
        r_cap.font.color.rgb = RGBColor(100, 116, 139)

    # Page Break for clean reading
    doc.add_page_break()

    # ----------------- BAB 2: PENJELASAN TAHAPAN FLOWCHART -----------------
    h2 = doc.add_heading(level=1)
    h2.paragraph_format.space_before = Pt(14)
    h2.paragraph_format.space_after = Pt(6)
    r_h2 = h2.add_run("2. Rincian dan Mekanisme Setiap Tahapan")
    r_h2.font.name = "Calibri"
    r_h2.font.size = Pt(14)
    r_h2.font.color.rgb = RGBColor(2, 132, 199)

    stages = [
        ("Tahap I: Pengadaan & Penerimaan Bahan Baku (Inbound Inventory)",
         "Fase ini mengatur masuknya bahan baku fisik dari para pemasok:",
         [
             ("Purchase Order (PO)", "Dokumen pemesanan bahan baku ke supplier (Kayu Mahoni, Kaki Besi, Baut, Cat). Pada tahap ini belum ada mutasi stok fisik di sistem."),
             ("Purchase Receipt (Tanda Terima)", "Titik masuk persediaan fisik ke gudang 'Stores - VD'. Dokumen ini otomatis menambah kuantitas dan nilai stok pada Stock Ledger."),
             ("Jurnal Otomatis Akuntansi", "ERPNext menerapkan sistem Persediaan Abadi (Perpetual Inventory). Saat Purchase Receipt disubmit, sistem otomatis menjurnal:\n• Debit: Akun Persediaan Bahan Baku (Stock In Hand)\n• Kredit: Akun Hutang Barang Belum Ditagih (Stock Received But Not Billed)"),
             ("Purchase Invoice", "Penerimaan faktur dari supplier yang mengonversi hutang belum ditagih menjadi Hutang Usaha (Accounts Payable).")
         ]),
        ("Tahap II: Pengeluaran Bahan ke Ruang Perakitan (Work In Progress / WIP)",
         "Fase ini mengatur pergerakan bahan mentah yang mulai diproses di lantai pabrik:",
         [
             ("Work Order", "Dokumen perintah produksi yang merujuk pada Bill of Materials (BOM) produk FG-MEJA-01. Work Order merinci bahan baku yang dibutuhkan."),
             ("Stock Entry: Material Transfer for Manufacture", "Dibuat saat tombol 'Start' pada Work Order diklik. Dokumen ini memindahkan bahan baku dari gudang penyimpanan bahan baku ('Stores - VD') ke gudang perakitan ('Work In Progress - VD')."),
             ("Efek Stok & Akuntansi", "• Gudang Stores - VD: Stok bahan mentah berkurang (-RM).\n• Gudang Work In Progress - VD: Saldo barang dalam proses bertambah (+WIP).\n• Jurnal: Debit Akun Persediaan WIP | Kredit Akun Persediaan Bahan Baku.")
         ]),
        ("Tahap III: Penyelesaian Produksi & Penerimaan Produk Jadi",
         "Fase ini menandai selesainya perakitan meja dan menjadi produk siap jual:",
         [
             ("Stock Entry: Manufacture", "Dibuat saat tombol 'Finish' pada Work Order diklik."),
             ("Konsumsi Bahan Baku", "Sistem secara otomatis menghapus/mengonsumsi saldo bahan yang ada di gudang 'Work In Progress - VD'."),
             ("Penerimaan Barang Jadi", "Sistem otomatis menambahkan produk jadi (FG-MEJA-01) ke dalam gudang 'Finished Goods - VD' sebesar kuantitas yang diproduksi."),
             ("Valuasi Harga Pokok Produksi (HPP)", "Nilai stok meja dihitung dari total biaya bahan baku yang diserap sesuai resep BOM (Rp 299.000 per meja).\n• Jurnal: Debit Akun Persediaan Barang Jadi | Kredit Akun Persediaan WIP.")
         ]),
        ("Tahap IV: Pengeluaran Persediaan untuk Penjualan (Outbound Inventory)",
         "Fase penyerahan barang jadi kepada pembeli:",
         [
             ("Sales Order", "Konfirmasi pesanan dari pelanggan (misal: CV Sentra Mebel Indonesia)."),
             ("Delivery Note (Surat Jalan)", "Dokumen utama pengurangan stok produk jadi. Barang dikeluarkan secara resmi dari gudang 'Finished Goods - VD'."),
             ("Pencatatan Beban Pokok Penjualan (COGS)", "Saat Delivery Note disubmit, sistem otomatis mengakui biaya barang yang keluar:\n• Debit: Beban Pokok Penjualan / Cost of Goods Sold (COGS)\n• Kredit: Akun Persediaan Barang Jadi (Stock In Hand)"),
             ("Sales Invoice & Pembayaran", "Penerbitan faktur tagihan dan pencatatan penerimaan uang kas/bank dari pelanggan.")
         ])
    ]

    for title, desc, points in stages:
        p_st = doc.add_paragraph()
        p_st.paragraph_format.space_before = Pt(10)
        p_st.paragraph_format.space_after = Pt(2)
        r_st = p_st.add_run(f"■ {title}")
        r_st.bold = True
        r_st.font.name = "Calibri"
        r_st.font.size = Pt(12)
        r_st.font.color.rgb = RGBColor(30, 41, 59)

        p_sd = doc.add_paragraph()
        p_sd.paragraph_format.space_after = Pt(4)
        r_sd = p_sd.add_run(desc)
        r_sd.italic = True
        r_sd.font.name = "Calibri"
        r_sd.font.size = Pt(10)

        for p_name, p_val in points:
            p_pt = doc.add_paragraph(style='List Bullet')
            p_pt.paragraph_format.space_before = Pt(1)
            p_pt.paragraph_format.space_after = Pt(2)
            r_pn = p_pt.add_run(f"{p_name}: ")
            r_pn.bold = True
            r_pn.font.name = "Calibri"
            r_pn.font.size = Pt(10)
            r_pv = p_pt.add_run(p_val)
            r_pv.font.name = "Calibri"
            r_pv.font.size = Pt(10)

    # ----------------- BAB 3: TABEL MATRIKS DOKUMEN -----------------
    h3 = doc.add_heading(level=1)
    h3.paragraph_format.space_before = Pt(16)
    h3.paragraph_format.space_after = Pt(6)
    r_h3 = h3.add_run("3. Matriks Dokumen, Mutasi Gudang, dan Jurnal Persediaan")
    r_h3.font.name = "Calibri"
    r_h3.font.size = Pt(14)
    r_h3.font.color.rgb = RGBColor(2, 132, 199)

    headers = ["Dokumen ERPNext", "Tipe Transaksi", "Gudang Asal", "Gudang Tujuan", "Mutasi Kuantitas", "Jurnal Akuntansi (Perpetual Inventory)"]
    table_data = [
        ["Purchase Receipt", "Inbound Pembelian", "Pemasok Eksternal", "Stores - VD", "+ Bahan Baku (RM)", "Dr. Persediaan Bahan Baku\nCr. Stock Received But Not Billed"],
        ["Stock Entry (Transfer)", "Material Transfer", "Stores - VD", "Work In Progress - VD", "- Stores / + WIP", "Dr. Persediaan WIP\nCr. Persediaan Bahan Baku"],
        ["Stock Entry (Manufacture)", "Penyelesaian Produksi", "Work In Progress - VD", "Finished Goods - VD", "- WIP / + Produk Jadi (FG)", "Dr. Persediaan Barang Jadi\nCr. Persediaan WIP"],
        ["Delivery Note", "Outbound Penjualan", "Finished Goods - VD", "Pelanggan Eksternal", "- Produk Jadi (FG)", "Dr. Beban Pokok Penjualan (HPP/COGS)\nCr. Persediaan Barang Jadi"],
        ["Stock Reconciliation", "Penyesuaian Fisik", "Semua Gudang", "Semua Gudang", "Koreksi Fisik (+ / -)", "Dr/Cr. Penyesuaian Persediaan (Stock Adjustment)\nCr/Dr. Akun Persediaan Terkait"]
    ]

    tbl = doc.add_table(rows=len(table_data) + 1, cols=len(headers))
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.style = 'Table Grid'

    # Header row
    for col_idx, text in enumerate(headers):
        cell = tbl.cell(0, col_idx)
        set_cell_background(cell, "0F172A")
        set_cell_margins(cell, top=100, bottom=100, left=120, right=120)
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(text)
        r.bold = True
        r.font.name = "Calibri"
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(255, 255, 255)

    # Data rows
    for row_idx, row in enumerate(table_data):
        bg = "F8FAFC" if row_idx % 2 == 1 else "FFFFFF"
        for col_idx, val in enumerate(row):
            cell = tbl.cell(row_idx + 1, col_idx)
            set_cell_background(cell, bg)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(2)
            r = p.add_run(val)
            r.font.name = "Calibri"
            r.font.size = Pt(9)
            r.font.color.rgb = RGBColor(30, 41, 59)

    # ----------------- BAB 4: PENGENDALIAN & MONITORING -----------------
    h4 = doc.add_heading(level=1)
    h4.paragraph_format.space_before = Pt(16)
    h4.paragraph_format.space_after = Pt(6)
    r_h4 = h4.add_run("4. Laporan & Pengendalian Persediaan di ERPNext")
    r_h4.font.name = "Calibri"
    r_h4.font.size = Pt(14)
    r_h4.font.color.rgb = RGBColor(2, 132, 199)

    reports = [
        ("Stock Ledger (Buku Besar Stok / Kartu Stok)", "Menampilkan seluruh riwayat kronologis pergerakan kuantitas masuk, keluar, dan saldo berjalan setiap item barang di masing-masing gudang, beserta nilai perolehannya berdasarkan metode FIFO (First In First Out)."),
        ("Stock Balance (Laporan Saldo Persediaan)", "Menampilkan posisi kuantitas dan nilai uang persediaan yang ada saat ini secara terperinci per gudang (Gudang Bahan Baku, WIP, dan Barang Jadi)."),
        ("Stock Projected Quantity", "Membantu bagian perencanaan dan pengadaan untuk melihat stok aktual, stok yang sudah dipesan dalam PO, stok yang sedang dirakit dalam Work Order, serta stok yang sudah dijanjikan kepada pelanggan (Reserved for Sales)."),
        ("Stock Ageing Report", "Mengetahui umur penyimpanan bahan baku dan produk jadi guna menghindari kerusakan material atau barang menumpuk terlalu lama (dead stock).")
    ]

    for rep_name, rep_desc in reports:
        p_r = doc.add_paragraph(style='List Bullet')
        p_r.paragraph_format.space_before = Pt(2)
        p_r.paragraph_format.space_after = Pt(2)
        r_rn = p_r.add_run(f"{rep_name}: ")
        r_rn.bold = True
        r_rn.font.name = "Calibri"
        r_rn.font.size = Pt(10)
        r_rd = p_r.add_run(rep_desc)
        r_rd.font.name = "Calibri"
        r_rd.font.size = Pt(10)

    doc.save(docx_path)
    print(f"Flowchart DOCX created: {docx_path}")

if __name__ == '__main__':
    img_path = "/tmp/ERP_Vlara/flowchart_persediaan_erpnext.png"
    docx_path = "/tmp/ERP_Vlara/FLOWCHART_SISTEM_PERSEDIAAN_ERPNEXT.docx"
    create_flowchart_image(img_path)
    create_flowchart_docx(docx_path, img_path)
