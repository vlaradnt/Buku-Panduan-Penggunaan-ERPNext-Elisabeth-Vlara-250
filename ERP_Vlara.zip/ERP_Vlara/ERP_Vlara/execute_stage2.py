import frappe
from frappe.utils import nowdate, add_days
from erpnext.buying.doctype.purchase_order.purchase_order import make_purchase_receipt, make_purchase_invoice
from erpnext.accounts.doctype.payment_entry.payment_entry import get_payment_entry

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    warehouse = "Stores - VD"
    today = nowdate()
    schedule_date = add_days(today, 3)

    print("=========================================================")
    print("=== MEMULAI EKSEKUSI TAHAP 2: PENGADAAN BAHAN BAKU ===")
    print("=========================================================")
    
    # 3 Purchase Order Scenarios sesuai Dokumen Skenario Transaksi
    po_scenarios = [
        {
            "supplier": "PT Rimba Kayu Lestari",
            "items": [
                {
                    "item_code": "RM-KAYU-01",
                    "qty": 15,
                    "rate": 85000.0,
                    "warehouse": warehouse
                }
            ]
        },
        {
            "supplier": "CV Logam Baja Perkasa",
            "items": [
                {
                    "item_code": "RM-BESI-01",
                    "qty": 50,
                    "rate": 40000.0,
                    "warehouse": warehouse
                },
                {
                    "item_code": "RM-BAUT-01",
                    "qty": 200,
                    "rate": 1500.0,
                    "warehouse": warehouse
                }
            ]
        },
        {
            "supplier": "Toko Cat Sumber Warna",
            "items": [
                {
                    "item_code": "RM-CAT-01",
                    "qty": 10,
                    "rate": 60000.0,
                    "warehouse": warehouse
                }
            ]
        }
    ]

    # Akun Kas / Bank untuk pembayaran: Kas Besar (IDR ledger account)
    paid_from_account = "1111.002 - Kas Besar - VD"

    results = []

    for idx, sc in enumerate(po_scenarios, 1):
        supplier = sc["supplier"]
        print(f"\n>>> Memproses Pengadaan #{idx}: {supplier}")

        # 1. Purchase Order
        po_doc = frappe.new_doc("Purchase Order")
        po_doc.company = company
        po_doc.supplier = supplier
        po_doc.transaction_date = today
        po_doc.schedule_date = schedule_date
        po_doc.set_warehouse = warehouse

        for itm in sc["items"]:
            po_doc.append("items", {
                "item_code": itm["item_code"],
                "qty": itm["qty"],
                "rate": itm["rate"],
                "warehouse": itm["warehouse"],
                "schedule_date": schedule_date
            })

        po_doc.save(ignore_permissions=True)
        po_doc.submit()
        print(f" [1/4] Purchase Order Sukses: {po_doc.name} (Total: Rp {po_doc.grand_total:,.2f})")

        # 2. Purchase Receipt
        pr_doc = make_purchase_receipt(po_doc.name)
        pr_doc.posting_date = today
        for itm in pr_doc.items:
            itm.warehouse = warehouse
        pr_doc.save(ignore_permissions=True)
        pr_doc.submit()
        print(f" [2/4] Purchase Receipt Sukses: {pr_doc.name} (Barang masuk ke {warehouse})")

        # 3. Purchase Invoice
        pi_doc = make_purchase_invoice(po_doc.name)
        pi_doc.posting_date = today
        pi_doc.save(ignore_permissions=True)
        pi_doc.submit()
        print(f" [3/4] Purchase Invoice Sukses: {pi_doc.name} (Status Tagihan: {pi_doc.status})")

        # 4. Payment Entry
        pe_doc = get_payment_entry("Purchase Invoice", pi_doc.name)
        pe_doc.posting_date = today
        pe_doc.paid_from = paid_from_account
        pe_doc.reference_no = f"PAY-{pi_doc.name}"
        pe_doc.reference_date = today
        pe_doc.save(ignore_permissions=True)
        pe_doc.submit()
        print(f" [4/4] Payment Entry Sukses: {pe_doc.name} (Lunas Rp {pe_doc.paid_amount:,.2f} via {paid_from_account})")

        results.append({
            "supplier": supplier,
            "po": po_doc.name,
            "pr": pr_doc.name,
            "pi": pi_doc.name,
            "pe": pe_doc.name,
            "total": po_doc.grand_total
        })

    frappe.db.commit()
    print("\n" + "="*60)
    print("=== HASIL AKHIR EKSEKUSI TAHAP 2 (SEMUA TRANSAKSI SELESAI) ===")
    print("="*60)
    for r in results:
        print(f"Pemasok: {r['supplier']:<25} | PO: {r['po']} | PR: {r['pr']} | PI: {r['pi']} | PE: {r['pe']} | Total: Rp {r['total']:>12,.2f}")

    print("\n=== STATUS SALDO STOK DI GUDANG BAHAN BAKU (Stores - VD) ===")
    stock_ledger = frappe.db.sql("""
        SELECT item_code, SUM(actual_qty) as qty 
        FROM `tabStock Ledger Entry` 
        WHERE warehouse = %s 
        GROUP BY item_code
        ORDER BY item_code
    """, warehouse, as_dict=True)
    for s in stock_ledger:
        print(f" - {s.item_code}: {s.qty} unit")
