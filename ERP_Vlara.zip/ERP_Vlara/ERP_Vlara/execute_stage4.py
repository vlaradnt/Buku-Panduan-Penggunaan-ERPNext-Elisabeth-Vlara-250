import frappe
from frappe.utils import nowdate
from erpnext.selling.doctype.sales_order.sales_order import make_delivery_note, make_sales_invoice
from erpnext.accounts.doctype.payment_entry.payment_entry import get_payment_entry

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    customer = "CV Sentra Mebel Indonesia"
    fg_warehouse = "Finished Goods - VD"
    item_code = "FG-MEJA-01"
    qty_to_sell = 3
    selling_rate = 650000.0
    paid_to_account = "1111.002 - Kas Besar - VD"
    today = nowdate()

    print("==================================================================")
    print("=== MEMULAI EKSEKUSI TAHAP 4: PENJUALAN (SELLING CYCLE) ===")
    print("==================================================================")

    # 1. Buat Sales Order (SO)
    print("\n--- 1. Pembuatan Sales Order (SO) ---")
    so_doc = frappe.new_doc("Sales Order")
    so_doc.company = company
    so_doc.customer = customer
    so_doc.transaction_date = today
    so_doc.delivery_date = today

    so_doc.append("items", {
        "item_code": item_code,
        "qty": qty_to_sell,
        "rate": selling_rate,
        "warehouse": fg_warehouse,
        "delivery_date": today
    })

    so_doc.save(ignore_permissions=True)
    so_doc.submit()
    print(f"[OK] Sales Order Disubmit: {so_doc.name}")
    print(f"     Pelanggan: {customer}")
    print(f"     Barang: {qty_to_sell} unit {item_code} @ Rp {selling_rate:,.2f}")
    print(f"     Total Penjualan: Rp {so_doc.grand_total:,.2f}")

    # 2. Buat Delivery Note (DN - Pengiriman Meja ke Pelanggan)
    print("\n--- 2. Pengiriman Barang (Delivery Note / Surat Jalan) ---")
    dn_doc = make_delivery_note(so_doc.name)
    dn_doc.posting_date = today
    for itm in dn_doc.items:
        itm.warehouse = fg_warehouse
    dn_doc.save(ignore_permissions=True)
    dn_doc.submit()
    print(f"[OK] Delivery Note Disubmit: {dn_doc.name}")
    print(f"     3 Unit Meja resmi keluar dari {fg_warehouse} dan dikirim ke {customer}!")

    # 3. Buat Sales Invoice (Faktur Penjualan)
    print("\n--- 3. Pembuatan Faktur Penjualan (Sales Invoice) ---")
    si_doc = make_sales_invoice(so_doc.name)
    si_doc.posting_date = today
    si_doc.save(ignore_permissions=True)
    si_doc.submit()
    print(f"[OK] Sales Invoice Disubmit: {si_doc.name}")
    print(f"     Total Tagihan: Rp {si_doc.grand_total:,.2f} (Status: {si_doc.status})")

    # 4. Buat Payment Entry (Penerimaan Kas dari Pelanggan)
    print("\n--- 4. Penerimaan Pembayaran Kas (Payment Entry) ---")
    pe_doc = get_payment_entry("Sales Invoice", si_doc.name)
    pe_doc.posting_date = today
    pe_doc.paid_to = paid_to_account
    pe_doc.reference_no = f"PAY-{si_doc.name}"
    pe_doc.reference_date = today
    pe_doc.save(ignore_permissions=True)
    pe_doc.submit()
    print(f"[OK] Payment Entry Disubmit: {pe_doc.name}")
    print(f"     Uang Masuk ke Akun: {paid_to_account}")
    print(f"     Jumlah Diterima: Rp {pe_doc.received_amount:,.2f}")

    # Reload SI untuk cek status akhir
    si_doc.reload()
    print(f"     Status Akhir Faktur: {si_doc.status} (Outstanding: Rp {si_doc.outstanding_amount:,.2f})")

    so_doc.reload()
    print(f"     Status Akhir Sales Order: {so_doc.status}")

    frappe.db.commit()

    print("\n" + "="*65)
    print("=== RINGKASAN SALDO AKHIR GUDANG PRODUK JADI (Finished Goods - VD) ===")
    print("="*65)
    
    stock_balances = frappe.db.sql("""
        SELECT warehouse, item_code, SUM(actual_qty) as qty 
        FROM `tabStock Ledger Entry` 
        WHERE company = %s AND warehouse = %s
        GROUP BY warehouse, item_code
    """, (company, fg_warehouse), as_dict=True)

    for sb in stock_balances:
        print(f"📍 {sb.warehouse}:")
        print(f"   • {sb.item_code} : {sb.qty} unit (Awal 5 unit - 3 terjual = {sb.qty} unit tersisa)")

    print("\n=== RINGKASAN KEUANGAN TRANSAKSI INI ===")
    print(f"• Pendapatan Penjualan (Revenue) : Rp {so_doc.grand_total:,.2f}")
    cogs = qty_to_sell * 299000.0
    profit = so_doc.grand_total - cogs
    print(f"• Beban Pokok Penjualan (HPP)    : 3 unit x Rp 299.000 = Rp {cogs:,.2f}")
    print(f"• Laba Kotor (Gross Profit)      : Rp {profit:,.2f} (~54% Margin)")

if __name__ == "__main__":
    run()
