# Paket Dataset Praktik ERPNext (Industri Manufaktur)

Folder **`ERP_Vlara`** ini berisi kumpulan dataset terstruktur dan skenario latihan lengkap untuk praktik mandiri, tugas kuliah, maupun simulasi operasional industri manufaktur di ERPNext.

---

## 📁 Daftar Berkas dalam Folder `ERP_Vlara`

| Nama Berkas | Format | Deskripsi |
| :--- | :--- | :--- |
| **[01_master_barang_items.csv](file:///D:/ERP_Vlara/ERP_Vlara/01_master_barang_items.csv)** | CSV | Data Master Barang: 1 Produk Jadi (Finished Goods) & 4 Bahan Baku (Raw Material). |
| **[02_master_gudang_warehouses.csv](file:///D:/ERP_Vlara/ERP_Vlara/02_master_gudang_warehouses.csv)** | CSV | Data Master Gudang: Gudang Bahan Baku, Gudang WIP (Produksi), dan Gudang Produk Jadi. |
| **[03_master_pemasok_suppliers.csv](file:///D:/ERP_Vlara/ERP_Vlara/03_master_pemasok_suppliers.csv)** | CSV | Data Master Pemasok (Supplier kayu, rangka besi, dan cat). |
| **[04_master_pelanggan_customers.csv](file:///D:/ERP_Vlara/ERP_Vlara/04_master_pelanggan_customers.csv)** | CSV | Data Master Pelanggan (Toko mebel & korporat pembeli meja). |
| **[05_bill_of_materials_bom.csv](file:///D:/ERP_Vlara/ERP_Vlara/05_bill_of_materials_bom.csv)** | CSV | Struktur Resep Produksi (BOM) pembuatan 1 unit meja lengkap dengan estimasi biaya. |
| **[06_skenario_transaksi_lengkap.md](file:///D:/ERP_Vlara/ERP_Vlara/06_skenario_transaksi_lengkap.md)** | Markdown | Panduan transaksi langkah-demi-langkah (PO -> Receipt -> BOM -> Work Order -> SO -> Invoicing). |

---

## 🏭 Studi Kasus Industri Manufaktur

* **Tipe Bisnis**: Industri Manufaktur Furniture Kayu & Besi.
* **Produk Utama**: **Meja Kerja Kayu Minimalis (`FG-MEJA-01`)**.
* **Bahan Baku yang Dibutuhkan untuk 1 Meja**:
  1. `RM-KAYU-01`: Papan Kayu Mahoni 120x60 (1 Unit) @ Rp 85.000
  2. `RM-BESI-01`: Kaki Meja Besi Hollow (4 Unit) @ Rp 40.000 = Rp 160.000
  3. `RM-BAUT-01`: Baut & Sekrup Meja M6 (16 Unit) @ Rp 1.500 = Rp 24.000
  4. `RM-CAT-01`: Cat Finishing Pelitur Kayu (0.5 Liter) @ Rp 60.000 = Rp 30.000
* **Total Biaya Bahan Baku per Unit (BOM)**: **Rp 299.000**
* **Harga Jual Standar**: **Rp 650.000**
* **Laba Kotor Estimasi per Unit**: **Rp 351.000** *(Margin ~54%)*

---

## 🚀 Urutan Alur Praktik di ERPNext

1. **Langkah 1 (Persiapan Data Master)**:
   * Masukkan data master gudang sesuai file `02_master_gudang_warehouses.csv`.
   * Masukkan data master barang sesuai file `01_master_barang_items.csv`.
   * Masukkan data master supplier sesuai file `03_master_pemasok_suppliers.csv`.
   * Masukkan data master customer sesuai file `04_master_pelanggan_customers.csv`.

2. **Langkah 2 (Pengadaan Bahan Baku - Purchasing)**:
   * Buat **Purchase Order** bahan baku ke supplier kayu, besi, dan cat.
   * Lakukan **Purchase Receipt** ke *Gudang Bahan Baku*.
   * Lakukan **Purchase Invoice** & pencatatan pembayaran.

3. **Langkah 3 (Manufaktur & Produksi)**:
   * Buat **BOM** (Bill of Materials) untuk produk `FG-MEJA-01`.
   * Buat **Work Order** untuk memproduksi sejumlah meja (misal: 5 unit).
   * Klik tombol **Start** untuk transfer bahan baku ke gudang produksi (*WIP*).
   * Klik tombol **Finish** untuk menyelesaikan produksi. Meja jadi otomatis masuk ke *Gudang Barang Jadi*.

4. **Langkah 4 (Penjualan - Sales)**:
   * Buat **Sales Order** ke pelanggan.
   * Kirim meja jadi melalui **Delivery Note**.
   * Buat **Sales Invoice** & catat penerimaan kas.

5. **Langkah 5 (Analisis Laporan)**:
   * Cek kartu stok di **Stock Ledger**.
   * Cek laporan laba rugi di **Profit and Loss Statement**.
