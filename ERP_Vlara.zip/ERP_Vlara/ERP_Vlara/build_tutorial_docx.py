import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=120, bottom=120, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def style_table(table, col_widths, header_bg="1B365D"):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(table.rows):
        is_header = (i == 0)
        for j, cell in enumerate(row.cells):
            cell.width = col_widths[j]
            set_cell_margins(cell, top=140, bottom=140, left=160, right=160)
            if is_header:
                set_cell_background(cell, header_bg)
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for run in p.runs:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                        run.font.size = Pt(9.5)
            else:
                if i % 2 == 1:
                    set_cell_background(cell, "F8FAFC")
                else:
                    set_cell_background(cell, "FFFFFF")
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.font.size = Pt(9.0)

def build_docx():
    doc = docx.Document()
    
    # Page setup (A4, 1 inch margin)
    for section in doc.sections:
        section.page_width = Inches(8.27)
        section.page_height = Inches(11.69)
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Document Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_title = p_title.add_run("SKEMA PELAKSANAAN & TUTORIAL PENGERJAAN SOAL ERPNEXT")
    r_title.font.name = "Arial"
    r_title.font.size = Pt(16)
    r_title.font.bold = True
    r_title.font.color.rgb = RGBColor(27, 54, 93)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_sub = p_sub.add_run("Simulasi Operasional Manufaktur End-to-End (PT Furnitur Kayu Jaya)\nPanduan Praktikum, Alur Dokumen, dan Analisis Jurnal Akuntansi")
    r_sub.font.name = "Arial"
    r_sub.font.size = Pt(11)
    r_sub.font.italic = True
    r_sub.font.color.rgb = RGBColor(100, 116, 139)

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # =========================================================================
    # BAB 1: SKEMA ARSITEKTUR & ALUR KERJA
    # =========================================================================
    h1 = doc.add_heading("1. Skema Arsitektur & Alur Transaksi Manufaktur", level=1)
    h1.runs[0].font.color.rgb = RGBColor(27, 54, 93)
    
    doc.add_paragraph(
        "Siklus operasional manufaktur pada ERPNext mencakup integrasi antara modul Pembelian (Buying), "
        "Manajemen Persediaan (Stock), Produksi (Manufacturing), Penjualan (Selling), dan Akuntansi (Accounting). "
        "Setiap tahapan transaksi saling menerbitkan dokumen resmi yang langsung memutakhirkan Stock Ledger dan General Ledger."
    )

    # Table Matriks Alur Dokumen
    doc.add_heading("Tabel 1.1 Matriks Alur Dokumen & Perpindahan Fisik", level=2)
    tbl_alur = doc.add_table(rows=1, cols=4)
    tbl_alur.rows[0].cells[0].paragraphs[0].add_run("Tahapan")
    tbl_alur.rows[0].cells[1].paragraphs[0].add_run("Dokumen ERPNext")
    tbl_alur.rows[0].cells[2].paragraphs[0].add_run("Gudang Terkait")
    tbl_alur.rows[0].cells[3].paragraphs[0].add_run("Perubahan Nilai & Fisik Persediaan")

    data_alur = [
        ("1. Pengadaan", "Purchase Receipt", "Stores Warehouse", "Masuk 100 Batang Kayu @ Rp 500.000 (+Rp 50.000.000)"),
        ("2. Pengeluaran Bahan", "Stock Entry (Transfer)", "Stores -> WIP Warehouse", "Pindah 20 Batang Kayu (Stores: -10jt, WIP: +10jt)"),
        ("3. Alokasi Biaya", "Journal Entry", "Bank BCA / Utang Gaji", "Bayar Listrik Rp 1.500.000 & Upah Buruh Rp 2.500.000"),
        ("4. Penyelesaian Produk", "Stock Entry (Manufacture)", "WIP -> Finished Goods", "Selesai 10 Unit Meja Kayu Jati (Nilai: Rp 14.000.000, HPP: Rp 1.400.000/unit)"),
        ("5. Pengiriman Penjualan", "Delivery Note", "Finished Goods Warehouse", "Keluar 5 Unit Meja Kayu Jati (HPP diakui Rp 7.000.000)"),
        ("6. Faktur Penjualan", "Sales Invoice", "Pelanggan (PT Mebel Sejahtera)", "Pengakuan Piutang & Pendapatan Rp 14.000.000"),
        ("7. Pelunasan Kas/Bank", "Payment Entry", "Bank BCA", "Terima Piutang Rp 14.000.000 & Bayar Utang Rp 50.000.000"),
    ]

    for row_data in data_alur:
        row = tbl_alur.add_row()
        for c_idx, text in enumerate(row_data):
            row.cells[c_idx].paragraphs[0].add_run(text)

    style_table(tbl_alur, [Inches(1.2), Inches(1.6), Inches(1.6), Inches(1.8)])
    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # =========================================================================
    # BAB 2: TUTORIAL LANGKAH DEMI LANGKAH
    # =========================================================================
    h2 = doc.add_heading("2. Panduan Langkah demi Langkah (Tutorial Klik ERPNext)", level=1)
    h2.runs[0].font.color.rgb = RGBColor(27, 54, 93)

    steps = [
        ("A. Prasyarat: Konfigurasi Akun Gudang & BOM", [
            "Buka menu Stock > Warehouse. Pastikan masing-masing gudang diatur akunnya: Stores = 1131 (Persediaan Bahan Baku), Work In Progress = 1133 (Persediaan WIP), dan Finished Goods = 1134 (Persediaan Barang Jadi).",
            "Buka menu Manufacturing > Bill of Materials (BOM) > Add BOM. Buat BOM untuk FG-MEJA-01 dengan formula: 1 Unit Meja Kayu Jati membutuhkan 2 Batang RM-KAYU-01 @ Rp 500.000. Simpan dan Submit sebagai BOM Default."
        ]),
        ("Soal 1: Pengadaan Bahan Baku Utama (PO, PR, PINV)", [
            "Membuat Purchase Order: Buka Buying > Purchase Order > Add PO. Pilih Supplier 'PT Kayu Perhutani', tanggal '05-10-2026', masukkan Item RM-KAYU-01 Qty 100 @ Rp 500.000 (Target: Stores Warehouse). Simpan dan Submit (Terbit ID PO).",
            "Membuat Purchase Receipt: Dari halaman PO, klik tombol 'Create' > 'Receipt'. Pastikan gudang tujuan adalah Stores Warehouse. Simpan dan Submit (Terbit ID PR). Jurnal: Debet 1131 Persediaan Bahan Baku Rp 50jt, Kredit 2113 Barang Belum Ditagih Rp 50jt.",
            "Membuat Purchase Invoice: Dari halaman PR, klik 'Create' > 'Invoice'. Set Credit To: 2111 (Utang Usaha Pemasok Bahan Baku) dengan termin kredit 30 hari. Simpan dan Submit (Terbit ID PINV)."
        ]),
        ("Soal 2: Pengeluaran Bahan Baku ke Lantai Produksi", [
            "Merilis Work Order: Buka Manufacturing > Work Order > Add WO. Pilih Item FG-MEJA-01, Qty 10 Unit, WIP Warehouse: Work In Progress, FG Warehouse: Finished Goods. Simpan dan Submit (Terbit ID WO).",
            "Transfer Bahan Baku ke WIP: Dari WO, klik tombol 'Start' > 'Material Transfer'. ERPNext otomatis memunculkan 20 batang RM-KAYU-01 dari Stores ke WIP Warehouse. Simpan dan Submit (Terbit ID Stock Entry Transfer). Jurnal: Debet 1133 Persediaan WIP Rp 10jt, Kredit 1131 Persediaan Bahan Baku Rp 10jt."
        ]),
        ("Soal 3: Biaya Overhead Pabrik (BOP) & Upah Kerja", [
            "Pembayaran Listrik Pabrik: Buka Accounting > Journal Entry > Add JE (Type: Bank Entry). Tanggal 10-10-2026. Baris 1: Debet 5220 (Listrik, Air & Gas Pabrik) Rp 1.500.000. Baris 2: Kredit 1113/1120 (Bank BCA) Rp 1.500.000. Isi Cheque/Ref No. Simpan dan Submit.",
            "Pencatatan Upah Buruh: Buka Accounting > Journal Entry > Add JE (Type: Journal Entry). Baris 1: Debet 5140 (Upah Buruh Langsung Pabrik) Rp 2.500.000. Baris 2: Kredit 2122 (Utang Gaji Buruh & Staf) Rp 2.500.000. Simpan dan Submit."
        ]),
        ("Soal 4: Penyelesaian Produksi & Alokasi Biaya Tambahan", [
            "Penyelesaian Work Order: Buka kembali Work Order Soal 2, klik tombol 'Finish' > 'Manufacture'.",
            "Input Additional Costs: Pada tabel Biaya Tambahan (Additional Costs), masukkan 2 baris: (1) Akun 5220 Listrik Pabrik Rp 1.500.000; (2) Akun 5140 Upah Buruh Langsung Rp 2.500.000. Total biaya tambahan = Rp 4.000.000.",
            "Verifikasi HPP: Total nilai meja 10 unit = Rp 10jt (bahan) + Rp 4jt (overhead & upah) = Rp 14.000.000 (HPP = Rp 1.400.000/unit). Simpan dan Submit (Terbit ID Stock Entry Manufacture)."
        ]),
        ("Soal 5: Penjualan & Pengiriman Produk Jadi", [
            "Membuat Sales Order: Buka Selling > Sales Order > Add SO. Customer: 'PT Mebel Sejahtera', tanggal 15-10-2026. Item FG-MEJA-01 Qty 5 @ Rp 2.800.000 (Total Rp 14.000.000). Simpan dan Submit (Terbit ID SO).",
            "Pengiriman Barang (Delivery Note): Dari SO, klik 'Create' > 'Delivery'. Pastikan gudang pengeluaran Finished Goods dan akun beban 5110 (Pemakaian Bahan / HPP). Simpan dan Submit (Terbit ID DN). Jurnal: Debet 5110 HPP Rp 7jt, Kredit 1134 Barang Jadi Rp 7jt.",
            "Faktur Penjualan (Sales Invoice): Dari DN, klik 'Create' > 'Invoice'. Set Debit To: 1121 (Piutang Usaha Lokal) dan Income Account: 4110 (Penjualan Produk Jadi). Termin kredit 14 hari. Simpan dan Submit (Terbit ID SINV)."
        ]),
        ("Soal 6: Penerimaan Kas & Pelunasan Utang Usaha", [
            "Penerimaan Piutang: Buka Sales Invoice Soal 5, klik 'Create' > 'Payment'. Type: Receive. Paid To: 1113/1120 (Bank BCA) Rp 14.000.000. Simpan dan Submit (Status Sales Invoice berubah menjadi Paid).",
            "Pelunasan Utang Pemasok: Buka Purchase Invoice Soal 1, klik 'Create' > 'Payment'. Type: Pay. Paid From: 1113/1120 (Bank BCA) Rp 50.000.000. Simpan dan Submit (Status Purchase Invoice berubah menjadi Paid)."
        ])
    ]

    for title, sub_steps in steps:
        h3 = doc.add_heading(title, level=2)
        h3.runs[0].font.color.rgb = RGBColor(30, 41, 59)
        for s in sub_steps:
            p = doc.add_paragraph(s, style='List Bullet')
            p.paragraph_format.space_after = Pt(4)

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # =========================================================================
    # BAB 3: KUNCI JAWABAN RESMI
    # =========================================================================
    h3 = doc.add_heading("3. Lembar Hasil & Kunci Jawaban Resmi ERPNext", level=1)
    h3.runs[0].font.color.rgb = RGBColor(27, 54, 93)

    doc.add_paragraph("Berikut adalah seluruh nomor dokumen resmi yang berhasil diterbitkan oleh sistem ERPNext beserta saldo buku besar akhir:")

    doc.add_heading("Tabel 3.1 Daftar Nomor ID Dokumen Resmi ERPNext (Tabel 3 Soal)", level=2)
    tbl_doc = doc.add_table(rows=1, cols=3)
    tbl_doc.rows[0].cells[0].paragraphs[0].add_run("Jenis Dokumen ERPNext")
    tbl_doc.rows[0].cells[1].paragraphs[0].add_run("Pihak / Gudang Terkait")
    tbl_doc.rows[0].cells[2].paragraphs[0].add_run("Nomor ID Dokumen Terbit")

    data_doc = [
        ("Purchase Order (Kayu Jati)", "PT Kayu Perhutani", "PUR-ORD-2026-00014"),
        ("Purchase Receipt (Penerimaan Bahan)", "Stores Warehouse", "MAT-PRE-2026-00004"),
        ("Purchase Invoice (Faktur Pembelian)", "PT Kayu Perhutani", "ACC-PINV-2026-00010"),
        ("Stock Entry (Material Transfer WIP)", "Stores -> WIP Warehouse", "MAT-STE-2026-00003"),
        ("Stock Entry (Manufacture Produksi)", "WIP -> Finished Goods", "MAT-STE-2026-00004"),
        ("Sales Order (Meja Kayu Jati)", "PT Mebel Sejahtera", "SAL-ORD-2026-00007"),
        ("Delivery Note (Pengiriman Meja)", "Finished Goods Warehouse", "MAT-DN-2026-00002"),
        ("Sales Invoice (Faktur Penjualan)", "PT Mebel Sejahtera", "ACC-SINV-2026-00007"),
        ("Payment Entry (Penerimaan Piutang)", "Bank BCA", "ACC-PAY-2026-00010"),
        ("Payment Entry (Pelunasan Utang)", "Bank BCA", "ACC-PAY-2026-00011"),
    ]

    for d in data_doc:
        row = tbl_doc.add_row()
        row.cells[0].paragraphs[0].add_run(d[0])
        row.cells[1].paragraphs[0].add_run(d[1])
        r = row.cells[2].paragraphs[0].add_run(d[2])
        r.font.bold = True

    style_table(tbl_doc, [Inches(2.2), Inches(2.0), Inches(2.0)])
    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    doc.add_heading("Tabel 3.2 Verifikasi Saldo Akhir Akun Utama (Trial Balance)", level=2)
    tbl_tb = doc.add_table(rows=1, cols=4)
    tbl_tb.rows[0].cells[0].paragraphs[0].add_run("Nama Akun Keuangan")
    tbl_tb.rows[0].cells[1].paragraphs[0].add_run("Kode Akun")
    tbl_tb.rows[0].cells[2].paragraphs[0].add_run("Saldo Akhir Kasus Ini")
    tbl_tb.rows[0].cells[3].paragraphs[0].add_run("Keterangan & Posisi Akun")

    data_tb = [
        ("Kas / Bank BCA", "1120 / 1113", "Rp -37.500.000,00", "Kredit (Mutasi Bersih: +14jt - 1.5jt - 50jt)"),
        ("Persediaan Bahan Baku", "1131", "Rp 40.000.000,00", "Debet (Sisa 80 batang @ Rp 500.000 di Stores)"),
        ("Persediaan Barang Dalam Proses (WIP)", "1133", "Rp 0,00", "Nihil (Bahan 10jt selesai 100% jadi meja)"),
        ("Persediaan Barang Jadi", "1134", "Rp 7.000.000,00", "Debet (Sisa 5 unit @ Rp 1.400.000 di FG Warehouse)"),
        ("Pendapatan Penjualan", "4110", "Rp 14.000.000,00", "Kredit (Penjualan 5 unit @ Rp 2.800.000)"),
        ("Harga Pokok Penjualan (HPP)", "5110", "Rp 7.000.000,00", "Debet (HPP dari 5 unit meja yang dikirim)"),
    ]

    for t in data_tb:
        row = tbl_tb.add_row()
        row.cells[0].paragraphs[0].add_run(t[0])
        row.cells[1].paragraphs[0].add_run(t[1])
        r = row.cells[2].paragraphs[0].add_run(t[2])
        r.font.bold = True
        row.cells[3].paragraphs[0].add_run(t[3])

    style_table(tbl_tb, [Inches(1.8), Inches(0.9), Inches(1.6), Inches(1.9)])
    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Save docx
    out_file = "/tmp/TUTORIAL_LENGKAP_PENGERJAAN_SOAL_ERPNEXT.docx"
    doc.save(out_file)
    print("Successfully built:", out_file)

if __name__ == "__main__":
    build_docx()
