import frappe
from frappe.utils import nowdate
from erpnext.buying.doctype.purchase_order.purchase_order import make_purchase_receipt, make_purchase_invoice
from erpnext.accounts.doctype.payment_entry.payment_entry import get_payment_entry

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    warehouse = "Stores - VD"
    today = nowdate()

    print(f"Testing Stage 2 with company: {company}, warehouse: {warehouse}, date: {today}")
    
    # Check current POs
    existing_pos = frappe.get_all("Purchase Order", filters={"company": company}, fields=["name", "supplier", "grand_total", "status"])
    print(f"Existing POs count: {len(existing_pos)}")
    for po in existing_pos:
        print(po)
