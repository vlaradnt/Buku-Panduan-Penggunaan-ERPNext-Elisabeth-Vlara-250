import frappe
from frappe.utils import nowdate

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    abbr = "VD"
    
    print("==================================================================")
    print("=== PENGERJAAN SOAL KASUS TRANSAKSI ERPNEXT MANUFAKTUR ===")
    print("    Perusahaan: PT Furnitur Kayu Jaya (Company: Vlara Danita)")
    print("==================================================================")

    # 0. Setup Defaults & BOM
    bank_account = f"1113 - Bank Operasional - IDR - {abbr}"
    frappe.db.set_value("Account", bank_account, "account_name", "Kas / Bank BCA")
    frappe.db.commit()

    # Check BOM for FG-MEJA-01 (1 unit needs 2 Batang RM-KAYU-01 @ 500.000)
    existing_boms = frappe.get_all("BOM", filters={"item": "FG-MEJA-01", "docstatus": 1})
    bom_doc = None
    for b in existing_boms:
        b_doc = frappe.get_doc("BOM", b.name)
        if len(b_doc.items) == 1 and b_doc.items[0].item_code == "RM-KAYU-01" and b_doc.items[0].qty == 2.0:
            bom_doc = b_doc
            break
            
    if not bom_doc:
        bom_doc = frappe.get_doc({
            "doctype": "BOM",
            "item": "FG-MEJA-01",
            "quantity": 1.0,
            "company": company,
            "currency": "IDR",
            "is_active": 1,
            "is_default": 1,
            "with_operations": 0,
            "rm_cost_as_per": "Valuation Rate",
            "items": [
                {
                    "item_code": "RM-KAYU-01",
                    "qty": 2.0,
                    "uom": "Batang",
                    "rate": 500000.0,
                    "stock_uom": "Nos",
                    "conversion_factor": 1.0
                }
            ]
        })
        bom_doc.insert(ignore_permissions=True)
        bom_doc.submit()
        print(f"[OK] BOM Baru Dibuat & Disubmit: {bom_doc.name}")
    else:
        frappe.db.set_value("BOM", bom_doc.name, "is_default", 1)
        print(f"[OK] BOM Menggunakan: {bom_doc.name}")

    results = {}
    today_date = nowdate()

    # ================================================================
    # SOAL 1: Pengadaan Bahan Baku Utama (Siklus Pembelian)
    # 100 batang RM-KAYU-01 @ 500.000 = 50.000.000
    # ================================================================
    print("\n--- SOAL 1: SIKLUS PEMBELIAN (PURCHASE) ---")

    po = frappe.get_doc({
        "doctype": "Purchase Order",
        "company": company,
        "supplier": "PT Kayu Perhutani",
        "transaction_date": today_date,
        "schedule_date": today_date,
        "currency": "IDR",
        "items": [
            {
                "item_code": "RM-KAYU-01",
                "qty": 100.0,
                "uom": "Batang",
                "rate": 500000.0,
                "schedule_date": today_date,
                "warehouse": f"Stores - {abbr}"
            }
        ]
    })
    po.insert(ignore_permissions=True)
    po.submit()
    results["PO"] = po.name
    print(f"[OK] Purchase Order Diterbitkan: {po.name}")

    from erpnext.buying.doctype.purchase_order.purchase_order import make_purchase_receipt
    pr_raw = make_purchase_receipt(po.name)
    pr = frappe.get_doc(pr_raw) if isinstance(pr_raw, dict) else pr_raw
    pr.set_posting_time = 1
    pr.posting_date = today_date
    pr.posting_time = "08:00:00"
    for item in pr.items:
        item.warehouse = f"Stores - {abbr}"
    pr.insert(ignore_permissions=True)
    pr.submit()
    results["PR"] = pr.name
    print(f"[OK] Purchase Receipt Diterbitkan: {pr.name}")

    from erpnext.stock.doctype.purchase_receipt.purchase_receipt import make_purchase_invoice
    pinv_raw = make_purchase_invoice(pr.name)
    pinv = frappe.get_doc(pinv_raw) if isinstance(pinv_raw, dict) else pinv_raw
    pinv.set_posting_time = 1
    pinv.posting_date = today_date
    pinv.posting_time = "08:30:00"
    pinv.credit_to = f"2111 - Utang Usaha Pemasok Bahan Baku - {abbr}"
    pinv.insert(ignore_permissions=True)
    pinv.submit()
    results["PINV"] = pinv.name
    print(f"[OK] Purchase Invoice Diterbitkan: {pinv.name}")


    # ================================================================
    # SOAL 2: Pengeluaran Bahan Baku ke Lantai Produksi (Material Transfer WIP)
    # Work Order 10 unit FG-MEJA-01, transfer 20 batang RM-KAYU-01
    # ================================================================
    print("\n--- SOAL 2: PENGELUARAN BAHAN BAKU KE PRODUKSI ---")

    wo = frappe.get_doc({
        "doctype": "Work Order",
        "company": company,
        "production_item": "FG-MEJA-01",
        "bom_no": bom_doc.name,
        "qty": 10.0,
        "wip_warehouse": f"Work In Progress - {abbr}",
        "fg_warehouse": f"Finished Goods - {abbr}",
        "planned_start_date": today_date,
        "status": "Submitted"
    })
    wo.insert(ignore_permissions=True)
    wo.submit()
    results["WO"] = wo.name
    print(f"[OK] Work Order Diterbitkan: {wo.name}")

    from erpnext.manufacturing.doctype.work_order.work_order import make_stock_entry
    ste_raw = make_stock_entry(wo.name, "Material Transfer for Manufacture", 10.0)
    ste_transfer = frappe.get_doc(ste_raw) if isinstance(ste_raw, dict) else ste_raw
    ste_transfer.set_posting_time = 1
    ste_transfer.posting_date = today_date
    ste_transfer.posting_time = "09:00:00"
    ste_transfer.from_warehouse = f"Stores - {abbr}"
    ste_transfer.to_warehouse = f"Work In Progress - {abbr}"
    for it in ste_transfer.items:
        it.s_warehouse = f"Stores - {abbr}"
        it.t_warehouse = f"Work In Progress - {abbr}"
    ste_transfer.insert(ignore_permissions=True)
    ste_transfer.submit()
    results["STE_TRANSFER"] = ste_transfer.name
    print(f"[OK] Stock Entry (Transfer WIP) Diterbitkan: {ste_transfer.name}")


    # ================================================================
    # SOAL 3: Pencatatan Beban Listrik Pabrik & Upah Buruh
    # Beban Listrik Pabrik Rp 1.500.000 via Bank BCA
    # Upah Buruh Langsung Pabrik Rp 2.500.000
    # ================================================================
    print("\n--- SOAL 3: BIAYA OVERHEAD PABRIK (BOP) & UPAH KERJA ---")

    # Journal Entry Beban Listrik via Bank BCA
    je_listrik = frappe.get_doc({
        "doctype": "Journal Entry",
        "company": company,
        "posting_date": today_date,
        "voucher_type": "Bank Entry",
        "cheque_no": "TRF-BCA-PLN-001",
        "cheque_date": today_date,
        "user_remark": "Pembayaran beban listrik pabrik via Transfer Bank BCA",
        "accounts": [
            {
                "account": f"5220 - Listrik, Air, & Gas Pabrik - {abbr}",
                "debit_in_account_currency": 1500000.0,
                "credit_in_account_currency": 0.0,
                "cost_center": f"Main - {abbr}"
            },
            {
                "account": bank_account,
                "debit_in_account_currency": 0.0,
                "credit_in_account_currency": 1500000.0
            }
        ]
    })
    je_listrik.insert(ignore_permissions=True)
    je_listrik.submit()
    results["JE_LISTRIK"] = je_listrik.name
    print(f"[OK] Journal Entry (Listrik Pabrik) Diterbitkan: {je_listrik.name}")

    # Journal Entry Akrual Upah Buruh Langsung Pabrik
    je_upah = frappe.get_doc({
        "doctype": "Journal Entry",
        "company": company,
        "posting_date": today_date,
        "voucher_type": "Journal Entry",
        "user_remark": "Alokasi beban upah buruh langsung pabrik",
        "accounts": [
            {
                "account": f"5140 - Upah Buruh Langsung Pabrik - {abbr}",
                "debit_in_account_currency": 2500000.0,
                "credit_in_account_currency": 0.0,
                "cost_center": f"Main - {abbr}"
            },
            {
                "account": f"2122 - Utang Gaji Buruh & Staf - {abbr}",
                "debit_in_account_currency": 0.0,
                "credit_in_account_currency": 2500000.0
            }
        ]
    })
    je_upah.insert(ignore_permissions=True)
    je_upah.submit()
    results["JE_UPAH"] = je_upah.name
    print(f"[OK] Journal Entry (Upah Buruh) Diterbitkan: {je_upah.name}")


    # ================================================================
    # SOAL 4: Penyelesaian Produksi Barang Jadi (Manufacture Entry)
    # 10 unit Meja Kayu Jati selesai diproduksi
    # Additional Costs: Listrik Rp 1.500.000 + Upah Rp 2.500.000 = Rp 4.000.000
    # ================================================================
    print("\n--- SOAL 4: PENYELESAIAN PRODUKSI (MANUFACTURE) ---")

    ste_mfg_raw = make_stock_entry(wo.name, "Manufacture", 10.0)
    ste_mfg = frappe.get_doc(ste_mfg_raw) if isinstance(ste_mfg_raw, dict) else ste_mfg_raw
    ste_mfg.set_posting_time = 1
    ste_mfg.posting_date = today_date
    ste_mfg.posting_time = "11:00:00"
    ste_mfg.from_warehouse = f"Work In Progress - {abbr}"
    ste_mfg.to_warehouse = f"Finished Goods - {abbr}"

    # Set additional costs (BOP & Upah)
    ste_mfg.additional_costs = []
    ste_mfg.append("additional_costs", {
        "expense_account": f"5220 - Listrik, Air, & Gas Pabrik - {abbr}",
        "description": "Beban Listrik Pabrik",
        "amount": 1500000.0
    })
    ste_mfg.append("additional_costs", {
        "expense_account": f"5140 - Upah Buruh Langsung Pabrik - {abbr}",
        "description": "Upah Buruh Langsung Pabrik",
        "amount": 2500000.0
    })

    ste_mfg.insert(ignore_permissions=True)
    ste_mfg.submit()
    results["STE_MFG"] = ste_mfg.name
    print(f"[OK] Stock Entry (Manufacture) Diterbitkan: {ste_mfg.name}")


    # ================================================================
    # SOAL 5: Penjualan Produk Jadi & Pengiriman Barang (Siklus Penjualan)
    # 5 unit FG-MEJA-01 @ Rp 2.800.000 = Rp 14.000.000 ke PT Mebel Sejahtera
    # ================================================================
    print("\n--- SOAL 5: SIKLUS PENJUALAN (SALES) ---")

    # 5.1 Sales Order
    so = frappe.get_doc({
        "doctype": "Sales Order",
        "company": company,
        "customer": "PT Mebel Sejahtera",
        "transaction_date": today_date,
        "delivery_date": today_date,
        "currency": "IDR",
        "items": [
            {
                "item_code": "FG-MEJA-01",
                "qty": 5.0,
                "uom": "Unit",
                "rate": 2800000.0,
                "delivery_date": today_date,
                "warehouse": f"Finished Goods - {abbr}"
            }
        ]
    })
    so.insert(ignore_permissions=True)
    so.submit()
    results["SO"] = so.name
    print(f"[OK] Sales Order Diterbitkan: {so.name}")

    # 5.2 Delivery Note
    from erpnext.selling.doctype.sales_order.sales_order import make_delivery_note
    dn_raw = make_delivery_note(so.name)
    dn = frappe.get_doc(dn_raw) if isinstance(dn_raw, dict) else dn_raw
    dn.set_posting_time = 1
    dn.posting_date = today_date
    dn.posting_time = "13:00:00"
    for item in dn.items:
        item.warehouse = f"Finished Goods - {abbr}"
        item.cost_center = f"Main - {abbr}"
        item.expense_account = f"5110 - Pemakaian Bahan Baku Utama - {abbr}"
    dn.insert(ignore_permissions=True)
    dn.submit()
    results["DN"] = dn.name
    print(f"[OK] Delivery Note Diterbitkan: {dn.name}")

    # 5.3 Sales Invoice
    from erpnext.stock.doctype.delivery_note.delivery_note import make_sales_invoice
    sinv_raw = make_sales_invoice(dn.name)
    sinv = frappe.get_doc(sinv_raw) if isinstance(sinv_raw, dict) else sinv_raw
    sinv.set_posting_time = 1
    sinv.posting_date = today_date
    sinv.posting_time = "14:00:00"
    sinv.debit_to = f"1121 - Piutang Usaha Lokal - {abbr}"
    for it in sinv.items:
        it.income_account = f"4110 - Penjualan Produk Jadi - Lokal - {abbr}"
        it.cost_center = f"Main - {abbr}"
    sinv.insert(ignore_permissions=True)
    sinv.submit()
    results["SINV"] = sinv.name
    print(f"[OK] Sales Invoice Diterbitkan: {sinv.name}")


    # ================================================================
    # SOAL 6: Penerimaan Piutang & Pelunasan Utang Usaha (Siklus Pembayaran)
    # 1. Pelunasan piutang PT Mebel Sejahtera Rp 14.000.000 via Bank BCA
    # 2. Pelunasan utang PT Kayu Perhutani Rp 50.000.000 via Bank BCA
    # ================================================================
    print("\n--- SOAL 6: SIKLUS PEMBAYARAN & PENERIMAAN ---")

    # 6.1 Payment Entry: Receive from Customer
    from erpnext.accounts.doctype.payment_entry.payment_entry import get_payment_entry
    pay_receive_raw = get_payment_entry("Sales Invoice", sinv.name, bank_account=bank_account)
    pay_receive = frappe.get_doc(pay_receive_raw) if isinstance(pay_receive_raw, dict) else pay_receive_raw
    pay_receive.posting_date = today_date
    pay_receive.paid_to = bank_account
    pay_receive.received_amount = 14000000.0
    pay_receive.paid_amount = 14000000.0
    pay_receive.reference_no = "TRF-BCA-CUST-001"
    pay_receive.reference_date = today_date
    pay_receive.insert(ignore_permissions=True)
    pay_receive.submit()
    results["PAY_RECEIVE"] = pay_receive.name
    print(f"[OK] Payment Entry (Penerimaan Piutang) Diterbitkan: {pay_receive.name}")

    # 6.2 Payment Entry: Pay to Supplier
    pay_supplier_raw = get_payment_entry("Purchase Invoice", pinv.name, bank_account=bank_account)
    pay_supplier = frappe.get_doc(pay_supplier_raw) if isinstance(pay_supplier_raw, dict) else pay_supplier_raw
    pay_supplier.posting_date = today_date
    pay_supplier.paid_from = bank_account
    pay_supplier.paid_amount = 50000000.0
    pay_supplier.received_amount = 50000000.0
    pay_supplier.reference_no = "TRF-BCA-SUPP-001"
    pay_supplier.reference_date = today_date
    pay_supplier.insert(ignore_permissions=True)
    pay_supplier.submit()
    results["PAY_SUPPLIER"] = pay_supplier.name
    print(f"[OK] Payment Entry (Pelunasan Utang) Diterbitkan: {pay_supplier.name}")

    frappe.db.commit()

    # ================================================================
    # VERIFIKASI SALDO TRIAL BALANCE SESUAI TABEL 3.1
    # ================================================================
    print("\n==================================================================")
    print("=== LEMBAR PENCATATAN HASIL TRANSAKSI (TABEL 3) ===")
    print("==================================================================")
    doc_table = [
        ("Purchase Order (Kayu Jati)", "PT Kayu Perhutani", results.get("PO")),
        ("Purchase Receipt (Penerimaan Bahan)", "Stores Warehouse", results.get("PR")),
        ("Purchase Invoice (Faktur Pembelian)", "PT Kayu Perhutani", results.get("PINV")),
        ("Stock Entry (Material Transfer WIP)", "Stores -> WIP Warehouse", results.get("STE_TRANSFER")),
        ("Stock Entry (Manufacture Produksi)", "WIP -> Finished Goods", results.get("STE_MFG")),
        ("Sales Order (Meja Kayu Jati)", "PT Mebel Sejahtera", results.get("SO")),
        ("Delivery Note (Pengiriman Meja)", "Finished Goods Warehouse", results.get("DN")),
        ("Sales Invoice (Faktur Penjualan)", "PT Mebel Sejahtera", results.get("SINV")),
        ("Payment Entry (Penerimaan Piutang)", "Bank BCA", results.get("PAY_RECEIVE")),
        ("Payment Entry (Pelunasan Utang)", "Bank BCA", results.get("PAY_SUPPLIER")),
    ]
    for jenis, pihak, no_id in doc_table:
        print(f"• {jenis:36} | {pihak:24} | {no_id}")

    print("\n==================================================================")
    print("=== TABEL 3.1 VERIFIKASI SALDO AKHIR AKUN UTAMA ===")
    print("==================================================================")
    
    target_accounts = [
        ("Kas / Bank BCA (1120)", [bank_account]),
        ("Persediaan Bahan Baku (1131)", [f"1131 - Persediaan Bahan Baku (Raw Material) - {abbr}"]),
        ("Persediaan Barang Dalam Proses / WIP (1133)", [f"1133 - Persediaan Barang Dalam Proses (WIP) - {abbr}"]),
        ("Persediaan Barang Jadi (1134)", [f"1134 - Persediaan Barang Jadi (Finished Goods) - {abbr}"]),
        ("Pendapatan Penjualan (4110)", [f"4110 - Penjualan Produk Jadi - Lokal - {abbr}"]),
        ("Harga Pokok Penjualan / HPP (5110)", [f"5110 - Pemakaian Bahan Baku Utama - {abbr}"])
    ]

    for label, acc_list in target_accounts:
        total_balance = 0.0
        acc_names = []
        for acc in acc_list:
            if frappe.db.exists("Account", acc):
                gl_entries = frappe.get_all("GL Entry", filters={"account": acc, "is_cancelled": 0}, fields=["debit", "credit"])
                bal = sum(g.debit - g.credit for g in gl_entries)
                root_type = frappe.db.get_value("Account", acc, "root_type")
                if root_type in ("Income", "Liability", "Equity"):
                    bal = -bal
                total_balance += bal
                acc_names.append(f"{acc} ({bal:,.2f})")
        print(f"• {label:42} : Rp {total_balance:,.2f}")

if __name__ == "__main__":
    run()
