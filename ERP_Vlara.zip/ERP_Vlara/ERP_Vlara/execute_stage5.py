import frappe
from frappe.utils import flt

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"

    print("==================================================================")
    print("=== TAHAP 5: EVALUASI LAPORAN AKHIR & ANALISIS KEUANGAN ===")
    print("==================================================================")

    # 1. EVALUASI KARTU STOK (STOCK LEDGER)
    print("\n" + "="*65)
    print("📊 1. REKAPITULASI KARTU STOK LENGKAP (STOCK LEDGER)")
    print("="*65)
    
    entries = frappe.db.sql("""
        SELECT 
            posting_date, voucher_type, voucher_no, warehouse, item_code, 
            actual_qty, qty_after_transaction, incoming_rate, valuation_rate, stock_value_difference
        FROM `tabStock Ledger Entry`
        WHERE company = %s
        ORDER BY creation ASC
    """, company, as_dict=True)

    print(f"{'Tanggal':<12} | {'Tipe Dokumen':<18} | {'No Bukti':<20} | {'Gudang':<22} | {'Item':<14} | {'Qty Mutasi':>10} | {'Saldo Akhir':>11}")
    print("-" * 125)
    for e in entries:
        print(f"{str(e.posting_date):<12} | {e.voucher_type:<18} | {e.voucher_no:<20} | {e.warehouse:<22} | {e.item_code:<14} | {e.actual_qty:>10.1f} | {e.qty_after_transaction:>11.1f}")

    print("\n--- SALDO AKHIR SEMUA BARANG PER GUDANG ---")
    balances = frappe.db.sql("""
        SELECT warehouse, item_code, SUM(actual_qty) as qty, AVG(valuation_rate) as val_rate
        FROM `tabStock Ledger Entry`
        WHERE company = %s
        GROUP BY warehouse, item_code
        HAVING SUM(actual_qty) > 0
        ORDER BY warehouse, item_code
    """, company, as_dict=True)

    total_stock_value = 0
    for b in balances:
        val = b.qty * b.val_rate
        total_stock_value += val
        print(f" • {b.warehouse:<24} | {b.item_code:<14} : {b.qty:>6.1f} unit @ Rp {b.val_rate:>10,.2f} = Rp {val:>12,.2f}")
    print(f"💰 Total Nilai Aset Persediaan di Gudang: Rp {total_stock_value:,.2f}")

    # 2. EVALUASI LAPORAN LABA RUGI (PROFIT AND LOSS)
    print("\n" + "="*65)
    print("📈 2. LAPORAN LABA RUGI (PROFIT AND LOSS STATEMENT)")
    print("="*65)

    # Ambil transaksi GL untuk akun Pendapatan dan Beban
    gl_entries = frappe.db.sql("""
        SELECT 
            gl.account, a.root_type, a.account_type, SUM(gl.debit) as total_debit, SUM(gl.credit) as total_credit
        FROM `tabGL Entry` gl
        JOIN `tabAccount` a ON gl.account = a.name
        WHERE gl.company = %s
        GROUP BY gl.account, a.root_type, a.account_type
        ORDER BY a.root_type DESC, gl.account ASC
    """, company, as_dict=True)

    revenue = 0.0
    expenses = 0.0

    print(f"{'Akun':<35} | {'Tipe Root':<10} | {'Debet (Rp)':>15} | {'Kredit (Rp)':>15}")
    print("-" * 85)
    for gl in gl_entries:
        net = 0
        if gl.root_type == "Income":
            net = flt(gl.total_credit) - flt(gl.total_debit)
            revenue += net
            print(f"{gl.account:<35} | {gl.root_type:<10} | {gl.total_debit:>15,.2f} | {gl.total_credit:>15,.2f} -> Net: Rp {net:,.2f}")
        elif gl.root_type == "Expense":
            net = flt(gl.total_debit) - flt(gl.total_credit)
            expenses += net
            print(f"{gl.account:<35} | {gl.root_type:<10} | {gl.total_debit:>15,.2f} | {gl.total_credit:>15,.2f} -> Net: Rp {net:,.2f}")

    gross_profit = revenue - expenses
    margin = (gross_profit / revenue * 100) if revenue > 0 else 0

    print("\n" + "="*50)
    print("📋 RINGKASAN KINERJA KEUANGAN PRAKTIK:")
    print("="*50)
    print(f" 1. Total Pendapatan Penjualan (Revenue) : Rp {revenue:>14,.2f}")
    print(f" 2. Beban Pokok Penjualan (HPP / COGS)   : Rp {expenses:>14,.2f}")
    print(f" ----------------------------------------------------- -")
    print(f" 3. Laba Kotor Bersih (Net Profit)       : Rp {gross_profit:>14,.2f}")
    print(f" 4. Margin Keuntungan Kotor              : {margin:>13.1f} %")
    print("="*50)

    # 3. POSISI KAS AKHIR
    print("\n💵 POSISI SALDO KAS TERKINI (1111.002 - Kas Besar - VD):")
    kas_entry = frappe.db.sql("""
        SELECT SUM(debit) as deb, SUM(credit) as cred 
        FROM `tabGL Entry` 
        WHERE account = '1111.002 - Kas Besar - VD' AND company = %s
    """, company, as_dict=True)[0]
    debet_kas = flt(kas_entry.deb) # Uang Masuk dari Pelanggan
    kredit_kas = flt(kas_entry.cred) # Uang Keluar bayar Supplier
    saldo_kas = debet_kas - kredit_kas
    print(f" • Total Uang Masuk (Penerimaan Penjualan) : Rp {debet_kas:>12,.2f}")
    print(f" • Total Uang Keluar (Pembayaran Bahan Baku): Rp {kredit_kas:>12,.2f}")
    print(f" • Saldo Kas Bersih Operasional            : Rp {saldo_kas:>12,.2f}")

if __name__ == "__main__":
    run()
