import zipfile
import xml.etree.ElementTree as ET
import os

doc_path = "/tmp/Soal_ERPNext_Manufaktur.docx"
out_path = "/tmp/Soal_ERPNext_Manufaktur_Terisi.docx"

# Replacements mapping
table2_answers = [
    ("Purchase Order", "PUR-ORD-2026-00014"),
    ("Purchase Receipt", "MAT-PRE-2026-00004"),
    ("Purchase Invoice", "ACC-PINV-2026-00010"),
    ("Material Transfer", "MAT-STE-2026-00003"),
    ("Manufacture Produksi", "MAT-STE-2026-00004"),
    ("Sales Order", "SAL-ORD-2026-00007"),
    ("Delivery Note", "MAT-DN-2026-00002"),
    ("Sales Invoice", "ACC-SINV-2026-00007"),
    ("Penerimaan Piutang", "ACC-PAY-2026-00010"),
    ("Pelunasan Utang", "ACC-PAY-2026-00011"),
]

table3_answers = [
    ("1120", "Rp -37.500.000,00 (Cr)"),
    ("1131", "Rp 40.000.000,00 (Dr)"),
    ("1133", "Rp 0,00 (Nihil)"),
    ("1134", "Rp 7.000.000,00 (Dr)"),
    ("4110", "Rp 14.000.000,00 (Cr)"),
    ("5110", "Rp 7.000.000,00 (Dr)"),
]

with zipfile.ZipFile(doc_path, 'r') as zin:
    xml_content = zin.read('word/document.xml')
    
tree = ET.fromstring(xml_content)
ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
tbls = tree.findall('.//w:tbl', ns)

# Table 2
t2 = tbls[2]
t2_rows = t2.findall('.//w:tr', ns)[1:]
for i, tr in enumerate(t2_rows):
    if i < len(table2_answers):
        cells = tr.findall('.//w:tc', ns)
        last_cell = cells[-1]
        for t in last_cell.findall('.//w:t', ns):
            if '...' in t.text or '..' in t.text:
                t.text = table2_answers[i][1]

# Table 3
t3 = tbls[3]
t3_rows = t3.findall('.//w:tr', ns)[1:]
for i, tr in enumerate(t3_rows):
    if i < len(table3_answers):
        cells = tr.findall('.//w:tc', ns)
        last_cell = cells[-1]
        for t in last_cell.findall('.//w:t', ns):
            if '...' in t.text or '..' in t.text:
                t.text = table3_answers[i][1]

new_xml = ET.tostring(tree, encoding='utf-8')

with zipfile.ZipFile(doc_path, 'r') as zin:
    with zipfile.ZipFile(out_path, 'w') as zout:
        for item in zin.infolist():
            if item.filename == 'word/document.xml':
                zout.writestr(item, new_xml)
            else:
                zout.writestr(item, zin.read(item.filename))

print("Successfully generated:", out_path)
