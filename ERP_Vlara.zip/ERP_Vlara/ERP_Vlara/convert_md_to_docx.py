import os
import re
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def add_formatted_text(paragraph, text, base_font_size=Pt(11), base_color=RGBColor(30, 41, 59)):
    # Pattern for bold, italic, code, link
    tokens = re.split(r'(\*\*.*?\*\*|\*.*?\*|`.*?`|\[.*?\]\(.*?\))', text)
    for token in tokens:
        if not token:
            continue
        if token.startswith('**') and token.endswith('**') and len(token) >= 4:
            inner = token[2:-2]
            run = paragraph.add_run(inner)
            run.bold = True
            run.font.size = base_font_size
            run.font.name = 'Calibri'
            run.font.color.rgb = base_color
        elif token.startswith('*') and token.endswith('*') and len(token) >= 2:
            inner = token[1:-1]
            run = paragraph.add_run(inner)
            run.italic = True
            run.font.size = base_font_size
            run.font.name = 'Calibri'
            run.font.color.rgb = base_color
        elif token.startswith('`') and token.endswith('`') and len(token) >= 2:
            inner = token[1:-1]
            run = paragraph.add_run(inner)
            run.font.size = Pt(10)
            run.font.name = 'Consolas'
            run.font.color.rgb = RGBColor(194, 65, 12)
        elif token.startswith('[') and '](' in token and token.endswith(')'):
            m = re.match(r'\[(.*?)\]\((.*?)\)', token)
            if m:
                label, url = m.groups()
                run = paragraph.add_run(label)
                run.font.size = base_font_size
                run.font.name = 'Calibri'
                run.font.color.rgb = RGBColor(37, 99, 235)
                run.underline = True
            else:
                run = paragraph.add_run(token)
                run.font.size = base_font_size
                run.font.name = 'Calibri'
        else:
            run = paragraph.add_run(token)
            run.font.size = base_font_size
            run.font.name = 'Calibri'
            run.font.color.rgb = base_color

def convert_markdown_to_docx(md_path, docx_path, main_title=""):
    with open(md_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    doc = docx.Document()
    
    # Page setup - Margins 1 inch
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    i = 0
    in_code_block = False
    code_lines = []
    
    while i < len(lines):
        line = lines[i].rstrip('\r\n')
        
        # Code block
        if line.startswith('```'):
            if in_code_block:
                # End code block
                table = doc.add_table(rows=1, cols=1)
                table.alignment = WD_TABLE_ALIGNMENT.CENTER
                cell = table.cell(0, 0)
                set_cell_background(cell, "F1F5F9")
                set_cell_margins(cell, top=140, bottom=140, left=200, right=200)
                cp = cell.paragraphs[0]
                cp.paragraph_format.space_before = Pt(2)
                cp.paragraph_format.space_after = Pt(2)
                run = cp.add_run("\n".join(code_lines))
                run.font.name = 'Consolas'
                run.font.size = Pt(9.5)
                run.font.color.rgb = RGBColor(30, 41, 59)
                doc.add_paragraph().paragraph_format.space_after = Pt(4)
                code_lines = []
                in_code_block = False
            else:
                in_code_block = True
                code_lines = []
            i += 1
            continue
            
        if in_code_block:
            code_lines.append(line)
            i += 1
            continue

        stripped = line.strip()
        
        # Blank line
        if not stripped:
            i += 1
            continue

        # Horizontal Rule
        if stripped in ['---', '***', '___']:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            p_border = parse_xml(f'<w:pBdr {nsdecls("w")}><w:bottom w:val="single" w:sz="6" w:space="1" w:color="CBD5E1"/></w:pBdr>')
            p._p.get_or_add_pPr().append(p_border)
            i += 1
            continue

        # Table detection
        if stripped.startswith('|') and stripped.endswith('|'):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith('|') and lines[i].strip().endswith('|'):
                table_lines.append(lines[i].strip())
                i += 1
                
            # Process table
            rows_data = []
            for tl in table_lines:
                # Split by | and ignore first and last empty
                cols = [c.strip() for c in tl.split('|')[1:-1]]
                # Ignore separator row like |:---|---:|
                if all(re.match(r'^:?-+:?$', c) for c in cols):
                    continue
                rows_data.append(cols)
                
            if rows_data:
                num_cols = max(len(r) for r in rows_data)
                tbl = doc.add_table(rows=len(rows_data), cols=num_cols)
                tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
                tbl.style = 'Table Grid'
                
                for r_idx, row in enumerate(rows_data):
                    is_header = (r_idx == 0)
                    for c_idx in range(num_cols):
                        cell = tbl.cell(r_idx, c_idx)
                        text_val = row[c_idx] if c_idx < len(row) else ""
                        cp = cell.paragraphs[0]
                        cp.paragraph_format.space_before = Pt(4)
                        cp.paragraph_format.space_after = Pt(4)
                        set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
                        
                        if is_header:
                            set_cell_background(cell, "1E293B") # Dark slate
                            add_formatted_text(cp, text_val, base_font_size=Pt(10), base_color=RGBColor(255, 255, 255))
                            for r in cp.runs:
                                r.bold = True
                        else:
                            bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
                            set_cell_background(cell, bg)
                            add_formatted_text(cp, text_val, base_font_size=Pt(9.5), base_color=RGBColor(51, 65, 85))
                            
                doc.add_paragraph().paragraph_format.space_after = Pt(6)
            continue

        # Headings
        if stripped.startswith('# '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(16)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.keep_with_next = True
            add_formatted_text(p, stripped[2:], base_font_size=Pt(18), base_color=RGBColor(15, 23, 42))
            for r in p.runs:
                r.bold = True
            i += 1
            continue
            
        if stripped.startswith('## '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(5)
            p.paragraph_format.keep_with_next = True
            add_formatted_text(p, stripped[3:], base_font_size=Pt(14), base_color=RGBColor(30, 41, 59))
            for r in p.runs:
                r.bold = True
            i += 1
            continue

        if stripped.startswith('### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.keep_with_next = True
            add_formatted_text(p, stripped[4:], base_font_size=Pt(12), base_color=RGBColor(51, 65, 85))
            for r in p.runs:
                r.bold = True
            i += 1
            continue

        if stripped.startswith('#### '):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.keep_with_next = True
            add_formatted_text(p, stripped[5:], base_font_size=Pt(11), base_color=RGBColor(71, 85, 105))
            for r in p.runs:
                r.bold = True
            i += 1
            continue

        # Blockquote (> text)
        if stripped.startswith('> '):
            quote_text = stripped[2:]
            table = doc.add_table(rows=1, cols=1)
            cell = table.cell(0, 0)
            set_cell_background(cell, "EFF6FF") # Light blue
            set_cell_margins(cell, top=100, bottom=100, left=180, right=150)
            cp = cell.paragraphs[0]
            cp.paragraph_format.space_before = Pt(2)
            cp.paragraph_format.space_after = Pt(2)
            add_formatted_text(cp, quote_text, base_font_size=Pt(10), base_color=RGBColor(30, 58, 138))
            doc.add_paragraph().paragraph_format.space_after = Pt(4)
            i += 1
            continue

        # Bullet List (* or -)
        if stripped.startswith('* ') or stripped.startswith('- '):
            text_val = stripped[2:]
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(2)
            # Check indentation
            leading_spaces = len(line) - len(line.lstrip(' '))
            if leading_spaces >= 2:
                p.paragraph_format.left_indent = Inches(0.5)
            add_formatted_text(p, text_val, base_font_size=Pt(10.5))
            i += 1
            continue

        # Numbered List (1. item)
        num_match = re.match(r'^(\d+)\.\s+(.*)', stripped)
        if num_match:
            text_val = num_match.group(2)
            p = doc.add_paragraph(style='List Number')
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(2)
            add_formatted_text(p, text_val, base_font_size=Pt(10.5))
            i += 1
            continue

        # Regular Paragraph
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.line_spacing = 1.15
        add_formatted_text(p, stripped, base_font_size=Pt(10.5))
        i += 1

    doc.save(docx_path)
    print(f"Successfully converted: {docx_path}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        base_dir = sys.argv[1]
    elif os.path.exists('/tmp/ERP_Vlara'):
        base_dir = '/tmp/ERP_Vlara'
    elif os.path.exists(r'D:\ERP_Vlara\ERP_Vlara'):
        base_dir = r'D:\ERP_Vlara\ERP_Vlara'
    else:
        base_dir = '.'
        
    md_files = [
        ('README_PANDUAN_PRAKTIK.md', 'README_PANDUAN_PRAKTIK.docx'),
        ('06_skenario_transaksi_lengkap.md', '06_skenario_transaksi_lengkap.docx')
    ]
    
    for md_name, docx_name in md_files:
        src = os.path.join(base_dir, md_name)
        dst = os.path.join(base_dir, docx_name)
        if os.path.exists(src):
            convert_markdown_to_docx(src, dst)
        else:
            print(f"File not found: {src}")
