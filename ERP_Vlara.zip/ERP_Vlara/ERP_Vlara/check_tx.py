import frappe

def run():
    frappe.set_user("Administrator")
    pos = frappe.get_all("Purchase Order", filters={"company": "Vlara Danita"}, fields=["name", "supplier", "status", "docstatus"])
    prs = frappe.get_all("Purchase Receipt", filters={"company": "Vlara Danita"}, fields=["name", "supplier", "status", "docstatus"])
    pis = frappe.get_all("Purchase Invoice", filters={"company": "Vlara Danita"}, fields=["name", "supplier", "status", "docstatus"])
    pes = frappe.get_all("Payment Entry", filters={"company": "Vlara Danita"}, fields=["name", "party", "status", "docstatus"])
    
    print("POs:", pos)
    print("PRs:", prs)
    print("PIs:", pis)
    print("PEs:", pes)
