import frappe
import openpyxl

# Mapping root type dari Bahasa Indonesia ke ERPNext English
ROOT_TYPE_MAP = {
    "Aset": "Asset",
    "Kewajiban": "Liability",
    "Ekuitas": "Equity",
    "Pendapatan": "Income",
    "Beban": "Expense"
}

# Akun root yang sudah ada di ERPNext, dipetakan dari root_type ke nama akun yang benar
ROOT_ACCOUNT_MAP = {
    "Asset":     "1000.000 - Aktiva - VD",
    "Liability": "2000.000 - Passiva - VD",
    "Equity":    "3000.000 - Modal - VD",
    "Income":    "4000.000 - Penjualan - VD",
    "Expense":   "5000.000 - Beban - VD",
}

def build_parent(par_str, abbr, root_type_en):
    """Resolve parent account: lookup by constructed name, fallback to root"""
    if not par_str:
        return None
    # par_str format in Excel: "1110 - Kas dan Bank"
    parts = par_str.split(" - ", 1)
    if len(parts) == 2:
        par_code = parts[0].strip()
        par_name = parts[1].strip()
        # Try direct lookup by constructed full name
        expected = f"{par_code} - {par_name} - {abbr}"
        if frappe.db.exists("Account", expected):
            return expected
        # Fallback: search by account_number + company
        found = frappe.db.get_value("Account", {"account_number": par_code, "company": f"Vlara Danita"}, "name")
        if found:
            return found
    # Ultimate fallback: use the root account for this root_type
    return ROOT_ACCOUNT_MAP.get(root_type_en)

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    company_doc = frappe.get_doc("Company", company)
    abbr = company_doc.abbr  # "VD"

    wb = openpyxl.load_workbook("/tmp/Kode_Akun_ERPNext_Manufaktur.xlsx")
    ws = wb["Bagan Akun Manufaktur"]
    rows = list(ws.iter_rows(values_only=True))[1:]

    print("==================================================================")
    print("=== PEMASANGAN KODE AKUN MANUFAKTUR (CHART OF ACCOUNTS) ===")
    print(f"    Company: {company} | Abbr: {abbr} | Total Baris: {len(rows)}")
    print("==================================================================")

    # Parse all rows
    accounts_ordered = []
    for r in rows:
        code    = str(r[0]).strip()
        id_name = str(r[1]).strip()
        parent  = str(r[3]).strip() if r[3] else None
        root_id = str(r[4]).strip() if r[4] else None
        is_grp  = True if str(r[5]).strip().lower() in ("ya", "yes", "true", "1") else False
        acc_type= str(r[6]).strip() if r[6] else ""

        root_en = ROOT_TYPE_MAP.get(root_id, root_id)

        accounts_ordered.append({
            "code":         code,
            "id_name":      id_name,
            "root_type":    root_en,
            "parent_raw":   parent,
            "is_group":     is_grp,
            "account_type": acc_type,
        })

    # Process in topological order (Excel rows already ordered top-down)
    # Skip first-level roots that already exist; they map to existing root accounts
    EXISTING_ROOT_CODES = {"1000", "2000", "3000", "4000", "5000"}

    created = []
    skipped = []
    errors  = []

    for acc in accounts_ordered:
        full_name = f"{acc['code']} - {acc['id_name']} - {abbr}"

        # Skip root-level accounts from Excel (they don't match existing naming format)
        if acc["code"] in EXISTING_ROOT_CODES:
            skipped.append(f"[ROOT SKIP] {full_name}")
            continue

        # Check if account already exists by name
        if frappe.db.exists("Account", full_name):
            skipped.append(f"[EXISTS] {full_name}")
            continue

        # Check if account_number already used by another account
        existing_with_num = frappe.db.get_value("Account", {"account_number": acc["code"], "company": company}, "name")
        if existing_with_num:
            skipped.append(f"[NUM EXISTS: {existing_with_num}] {full_name}")
            continue

        # Resolve parent
        parent_full = build_parent(acc["parent_raw"], abbr, acc["root_type"])

        try:
            doc = frappe.new_doc("Account")
            doc.account_name   = acc["id_name"]
            doc.account_number = acc["code"]
            doc.company        = company
            doc.root_type      = acc["root_type"]
            doc.parent_account = parent_full
            doc.is_group       = 1 if acc["is_group"] else 0
            doc.account_type   = acc["account_type"] if acc["account_type"] else None
            doc.insert(ignore_permissions=True)
            created.append(full_name)
            print(f"[OK] {full_name}")
            print(f"       Parent: {parent_full}")
        except Exception as e:
            errors.append((full_name, str(e)[:150]))
            print(f"[ERR] {full_name}: {str(e)[:150]}")

    frappe.db.commit()

    print("\n" + "="*60)
    print(f"  ✅ Total Berhasil Dibuat : {len(created)}")
    print(f"  ⏭  Total Dilewati (Skip) : {len(skipped)}")
    print(f"  ❌ Total Error           : {len(errors)}")
    print("="*60)

    if errors:
        print("\n--- DETAIL ERRORS ---")
        for name, err in errors:
            print(f"  ❌ {name}")
            print(f"      => {err}")

if __name__ == "__main__":
    run()
