import inspect
from erpnext.selling.doctype.sales_order.sales_order import make_delivery_note, make_sales_invoice

def run():
    print("make_delivery_note:")
    print(inspect.getsource(make_delivery_note))
    print("\nmake_sales_invoice:")
    print(inspect.getsource(make_sales_invoice))
