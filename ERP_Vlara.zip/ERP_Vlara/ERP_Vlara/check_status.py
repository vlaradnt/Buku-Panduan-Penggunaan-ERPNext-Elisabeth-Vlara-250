import frappe

def run():
    frappe.set_user("Administrator")
    print("=== COMPANIES ===")
    companies = frappe.get_all("Company", fields=["name", "abbr", "default_currency", "default_cash_account", "default_bank_account", "default_payable_account"])
    for c in companies:
        print(c)

    print("\n=== WAREHOUSES ===")
    warehouses = frappe.get_all("Warehouse", fields=["name", "warehouse_name", "company", "is_group"])
    for w in warehouses:
        print(w)

    print("\n=== SUPPLIERS ===")
    suppliers = frappe.get_all("Supplier", fields=["name", "supplier_name", "supplier_group"])
    for s in suppliers:
        print(s)

    print("\n=== ITEMS ===")
    items = frappe.get_all("Item", fields=["name", "item_code", "item_name", "stock_uom", "standard_rate"])
    for i in items:
        print(i)

    print("\n=== ACCOUNTS (Payable & Cash/Bank) ===")
    accounts = frappe.get_all("Account", filters={"account_type": ["in", ["Payable", "Cash", "Bank"]]}, fields=["name", "account_name", "account_type", "company"])
    for a in accounts:
        print(a)
