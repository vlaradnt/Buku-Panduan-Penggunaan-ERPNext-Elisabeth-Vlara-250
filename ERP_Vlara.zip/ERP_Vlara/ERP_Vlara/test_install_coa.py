import frappe
import openpyxl

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    company_doc = frappe.get_doc("Company", company)
    abbr = company_doc.abbr

    wb = openpyxl.load_workbook("/tmp/Kode_Akun_ERPNext_Manufaktur.xlsx")
    ws = wb["Bagan Akun Manufaktur"]
    rows = list(ws.iter_rows(values_only=True))[1:]

    excel_nums = [str(r[0]).strip() for r in rows]
    existing_accounts = frappe.db.get_all("Account", filters={"company": company}, fields=["name", "account_number"])
    num_map = {a.account_number: a.name for a in existing_accounts if a.account_number}

    clashes = []
    for n in excel_nums:
        if n in num_map:
            clashes.append((n, num_map[n]))

    print(f"Account Number Clashes in {company}: {len(clashes)}")
    for c in clashes:
        print(f"  Clash: {c[0]} is already used by {c[1]}")
