import frappe

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    abbr = "VD"

    print("--- 1. Pastikan UOM Batang dan Kaleng Tersedia ---")
    for uom_name in ["Batang", "Kaleng", "Unit"]:
        if not frappe.db.exists("UOM", uom_name):
            uom = frappe.get_doc({
                "doctype": "UOM",
                "uom_name": uom_name
            }).insert(ignore_permissions=True)
            print(f"UOM {uom_name} created.")
        else:
            print(f"UOM {uom_name} already exists.")

    print("\n--- 2. Update / Buat Pemasok PT Kayu Perhutani (SUP-001) ---")
    supp_name = "PT Kayu Perhutani"
    if not frappe.db.exists("Supplier", supp_name):
        supp = frappe.get_doc({
            "doctype": "Supplier",
            "supplier_name": supp_name,
            "supplier_group": "All Supplier Groups",
            "supplier_type": "Company"
        }).insert(ignore_permissions=True)
        print(f"Supplier {supp_name} created.")
    else:
        print(f"Supplier {supp_name} exists.")

    print("\n--- 3. Update / Buat Pelanggan PT Mebel Sejahtera (CUST-001) ---")
    cust_name = "PT Mebel Sejahtera"
    if not frappe.db.exists("Customer", cust_name):
        cust = frappe.get_doc({
            "doctype": "Customer",
            "customer_name": cust_name,
            "customer_group": "Commercial",
            "customer_type": "Company",
            "territory": "Indonesia"
        }).insert(ignore_permissions=True)
        print(f"Customer {cust_name} created.")
    else:
        print(f"Customer {cust_name} exists.")

    print("\n--- 4. Update Warehouse Accounts ---")
    wh_map = {
        f"Stores - {abbr}": f"1131 - Persediaan Bahan Baku (Raw Material) - {abbr}",
        f"Work In Progress - {abbr}": f"1133 - Persediaan Barang Dalam Proses (WIP) - {abbr}",
        f"Finished Goods - {abbr}": f"1134 - Persediaan Barang Jadi (Finished Goods) - {abbr}"
    }
    for wh, acc in wh_map.items():
        if frappe.db.exists("Warehouse", wh):
            frappe.db.set_value("Warehouse", wh, "account", acc)
            print(f"Warehouse {wh} set to account {acc}")

    print("\n--- 5. Update Items (Nama & UOM) ---")
    items_info = [
        ("RM-KAYU-01", "Kayu Jati Olahan", "Batang", f"Stores - {abbr}"),
        ("RM-CAT-01", "Cat & Vernis Kayu", "Kaleng", f"Stores - {abbr}"),
        ("FG-MEJA-01", "Meja Kayu Jati", "Unit", f"Finished Goods - {abbr}")
    ]
    for code, name, uom, def_wh in items_info:
        if frappe.db.exists("Item", code):
            item_doc = frappe.get_doc("Item", code)
            item_doc.item_name = name
            item_doc.default_warehouse = def_wh
            # check uoms
            has_uom = any(u.uom == uom for u in item_doc.uoms)
            if not has_uom:
                item_doc.append("uoms", {"uom": uom, "conversion_factor": 1.0})
            item_doc.save(ignore_permissions=True)
            print(f"Item {code} updated: {name} (Default WH: {def_wh})")

    frappe.db.commit()
    print("Setup master data selesai.")

if __name__ == "__main__":
    run()
