import frappe

def run():
    frappe.set_user("Administrator")
    company = "Vlara Danita"
    
    # 1. Master Items
    items = [
        {
            "item_code": "FG-MEJA-01",
            "item_name": "Meja Kerja Kayu Minimalis",
            "item_group": "Products",
            "stock_uom": "Nos",
            "is_stock_item": 1,
            "is_sales_item": 1,
            "is_purchase_item": 0,
            "standard_rate": 650000.0,
            "default_warehouse": "Finished Goods - VD",
            "description": "Produk Jadi Meja Belajar/Kerja Kayu dengan Rangka Kaki Besi"
        },
        {
            "item_code": "RM-KAYU-01",
            "item_name": "Papan Kayu Mahoni 120x60",
            "item_group": "Raw Material",
            "stock_uom": "Nos",
            "is_stock_item": 1,
            "is_sales_item": 0,
            "is_purchase_item": 1,
            "valuation_rate": 85000.0,
            "standard_rate": 85000.0,
            "default_warehouse": "Stores - VD",
            "description": "Papan kayu mahoni solid sudah diserut ukuran 120cm x 60cm"
        },
        {
            "item_code": "RM-BESI-01",
            "item_name": "Kaki Meja Besi Hollow",
            "item_group": "Raw Material",
            "stock_uom": "Nos",
            "is_stock_item": 1,
            "is_sales_item": 0,
            "is_purchase_item": 1,
            "valuation_rate": 40000.0,
            "standard_rate": 40000.0,
            "default_warehouse": "Stores - VD",
            "description": "Kaki meja bahan besi hollow coating hitam tinggi 70cm"
        },
        {
            "item_code": "RM-BAUT-01",
            "item_name": "Baut & Sekrup Meja M6",
            "item_group": "Raw Material",
            "stock_uom": "Nos",
            "is_stock_item": 1,
            "is_sales_item": 0,
            "is_purchase_item": 1,
            "valuation_rate": 1500.0,
            "standard_rate": 1500.0,
            "default_warehouse": "Stores - VD",
            "description": "Baut dan sekrup pengunci kayu dan rangka besi"
        },
        {
            "item_code": "RM-CAT-01",
            "item_name": "Cat Finishing Pelitur Kayu",
            "item_group": "Raw Material",
            "stock_uom": "Litre",
            "is_stock_item": 1,
            "is_sales_item": 0,
            "is_purchase_item": 1,
            "valuation_rate": 60000.0,
            "standard_rate": 60000.0,
            "default_warehouse": "Stores - VD",
            "description": "Cat pelitur kayu warna natural gloss"
        }
    ]
    
    created_items = []
    for item_data in items:
        code = item_data["item_code"]
        if not frappe.db.exists("Item", code):
            doc = frappe.get_doc({
                "doctype": "Item",
                **item_data
            })
            doc.insert(ignore_permissions=True)
            created_items.append(code)
            print(f"Item created: {code} - {item_data['item_name']}")
        else:
            print(f"Item already exists: {code}")

    # 2. Master Suppliers
    suppliers = [
        {"supplier_name": "PT Rimba Kayu Lestari", "supplier_group": "Raw Material", "country": "Indonesia"},
        {"supplier_name": "CV Logam Baja Perkasa", "supplier_group": "Hardware", "country": "Indonesia"},
        {"supplier_name": "Toko Cat Sumber Warna", "supplier_group": "Distributor", "country": "Indonesia"}
    ]
    
    created_suppliers = []
    for s_data in suppliers:
        s_name = s_data["supplier_name"]
        if not frappe.db.exists("Supplier", s_name):
            doc = frappe.get_doc({
                "doctype": "Supplier",
                **s_data
            })
            doc.insert(ignore_permissions=True)
            created_suppliers.append(s_name)
            print(f"Supplier created: {s_name}")
        else:
            print(f"Supplier already exists: {s_name}")

    # 3. Master Customers
    customers = [
        {"customer_name": "CV Sentra Mebel Indonesia", "customer_group": "Commercial", "territory": "Indonesia", "customer_type": "Company"},
        {"customer_name": "PT Kreasi Ruang Kantor", "customer_group": "Commercial", "territory": "Indonesia", "customer_type": "Company"},
        {"customer_name": "Toko Furniture Modern", "customer_group": "Individual", "territory": "Indonesia", "customer_type": "Individual"}
    ]
    
    created_customers = []
    for c_data in customers:
        c_name = c_data["customer_name"]
        if not frappe.db.exists("Customer", c_name):
            doc = frappe.get_doc({
                "doctype": "Customer",
                **c_data
            })
            doc.insert(ignore_permissions=True)
            created_customers.append(c_name)
            print(f"Customer created: {c_name}")
        else:
            print(f"Customer already exists: {c_name}")

    frappe.db.commit()
    print("\n--- STAGE 1 SUCCESSFUL ---")
    print(f"Items processed: {len(items)}")
    print(f"Suppliers processed: {len(suppliers)}")
    print(f"Customers processed: {len(customers)}")

if __name__ == "__main__":
    run()
